# 电子元器件参数自动提取系统：组员 C 后端交付

Python Flask + SQLite（建议Python 3.11及以上，本次实测3.13），按需求书第5章接口实现。运行入口是 `run.py`，提供 REST API，不包含组员B负责的前端。数据库自动建表，无需另装数据库服务。

## 快速运行（Windows PowerShell）

```powershell
cd 'E:\CityU Files\component-extractor-backend'
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements-lock.txt
Copy-Item .env.example .env
.venv\Scripts\python.exe scripts\seed_demo.py
.venv\Scripts\python.exe run.py
```

健康检查：`http://127.0.0.1:5000/api/health`。已安装依赖时可运行 `powershell -ExecutionPolicy Bypass -File .\start.ps1`。

`seed_demo.py` 创建 admin、auditor、demo 三个本地演示账户，随机密码在 `instance/demo-credentials.json`，不会打印密码或重置已有账户。它同时生成示例PDF/XLSX。这些数据是虚构教学样例，不代表真实元器件规格。密码文件、数据库、上传文件均不进入Git和发布ZIP。

服务启动后可运行 `.venv\Scripts\python.exe scripts\populate_demo.py`，通过真实HTTP将6个虚构器件提取、审核并发布，便于组员B联调。若已有演示数据则跳过，避免重复覆盖。

需要在屏幕上演示时，运行 `.venv\Scripts\python.exe scripts\desktop_demo.py`，点击“开始演示”。本地窗口会使用真实后端接口展示CSV上传、单位归一化、审核前隔离、403权限拦截、审核修正、范围查询、对比和CSV导出。每次新增一个LIVE-DEMO型号，导出文件与过程记录保存在instance目录；它是后端演示工具，不是组员B的业务前端。

如不需要演示账户，可自行创建管理员：

```powershell
.venv\Scripts\python.exe -m flask --app backend:create_app create-user --username myadmin --role admin
```

密码交互输入；无默认管理员密码。普通注册只能得到 `user`，管理员可通过 `/api/users` 创建其他角色。

## 完整业务流程

1. 登录，取得 `data.token`，之后携带 `Authorization: Bearer <token>`。
2. `POST /api/tasks` 创建人工/URL任务；或 `POST /api/tasks/upload` 上传PDF/CSV/XLSX，multipart字段为 `file`。
3. HTTP立即返回202，轮询 `/api/tasks/{id}`。`run.py` 中的后台线程从SQLite队列取任务，进程重启后pending任务仍在；processing任务租约到期会失败并允许重试。
4. `status=success` **只代表提取成功**，不代表发布。参数仅在任务草稿中，`review_status=pending`。
5. 审核员查看 `/api/audit/tasks/{id}`，可提交更正后的 `components`，然后 approve/reject。审核与整批发布在同一事务内：任意一条冲突则全部回滚。
6. approve后，正式参数才出现在组件查询、范围过滤、比较和导出中。reject不写正式参数。
7. 修改已发布组件同样生成待审核任务；审核前线上值保持原状，审核时检查版本防止覆盖并发更新。

需求书最简表结构无法表达审核草稿、数值单位、所有权和Token失效，因此实现保留六个核心实体含义，并增加必要字段及辅助表。`backend/schema.sql` 是实际建表依据，详见 `docs/ARCHITECTURE.md`。

## 提取能力与配置

默认 `EXTRACTION_MODE=rules`，不需要外部密钥，可验证人工、CSV、Excel及明确的 `Model: ...` / `Voltage: ...` 键值式PDF/网页。

真实厂商复杂数据手册建议在 `.env` 中配置：

```dotenv
EXTRACTION_MODE=llm
LLM_API_BASE=https://your-provider.example/v1
LLM_API_KEY=your-own-secret
LLM_MODEL=your-provider-model-name
```

使用兼容 `/chat/completions` 的服务，支持JSON对象响应。`LLM_MODEL`须按实际服务填写，无硬编码模型和虚构提取结果。`hybrid`模式尝试LLM，失败才回退规则并给出警告。文档内容会发给配置的服务商；人工/表格路径不调用LLM。连接器已做模拟服务测试，交付环境没有外部密钥，**未声称完成真实厂商API端到端测试或达到80%抽取准确率**。

- PDF支持文本层，不含OCR；扫描件会报错，需先OCR、另传文本版或人工录入。
- 每文件最多20MiB，PDF最多100页/120000字符，CSV/XLSX最多1000行；仅 `.pdf/.csv/.xlsx`，不支持旧 `.xls` 或宏工作簿。
- 规则解析不猜测缺失型号、厂商、类别。不支持把min/typ/max或数值区间自动合并成一个标量。
- 标准数值参数：voltage(V)、current(A)、resistance(Ω)、capacitance(F)、frequency(Hz)、power(W)、tolerance(%)；package保存为规范大写文本。支持中文别名及SI前缀。数值单位冲突直接报错；文件中缺单位可成为警告草稿，但审核前必须补齐。
- 启发式/模型自报的confidence不等于经过统计校准的概率。
- 网页遵守robots.txt，限制公网IP、80/443端口、响应大小及跳转；TCP连接固定到已验证IP，HTTPS保持域名证书验证。可配置 `URL_ALLOWED_HOSTS` 限制抓取域名。网络不可用或robots无法检查时失败，不绕过。

## 前端联调

接口用法见 `docs/API.md`，OpenAPI 3.0文件为 `docs/openapi.json`，原生JS调用示例为 `examples/api-client.js`。除下载接口外统一：

```json
{"code":0,"message":"success","data":{}}
```

错误使用对应HTTP状态和非零code；下载直接返回文件。页面请用HTTP服务启动，例如前端目录运行 `python -m http.server 5500`，不要从 `file://` 打开。默认仅允许 localhost/127.0.0.1:5500 的CORS，可在 `.env` 调整。未启用跨站Cookie，Token放Authorization头。

普通用户只能看到/修改自己创建的数据；审核员和管理员可查看全部，管理员才能删除。已发布的用户所有权不会因审核而转移给审核员。注册、登录、退出、提取、审核、编辑和删除均保留日志；退出会撤销数据库中的当前Token。

## 测试、备份与部署

```powershell
.venv\Scripts\python.exe -m pytest -q --junitxml=reports/pytest.xml
.venv\Scripts\python.exe scripts\benchmark.py
.venv\Scripts\python.exe scripts\http_smoke.py
.venv\Scripts\python.exe -m flask --app backend:create_app backup-db instance\backup-20261015.sqlite3
```

备份命令使用SQLite在线backup API；已有备份不会被覆盖。恢复前先停止服务，将备份复制到 `instance/components.sqlite3`，并一并保管上传源文件。备份仅含数据库，不含上传附件。

`run.py` 使用Waitress，单进程8个HTTP线程及一个后台工作线程，适合本机/课程演示。若使用单独WSGI服务，另启动 `.venv\Scripts\python.exe -m flask --app backend:create_app worker`；`flask run` 本身不会启动任务线程。不要将开发服务器直接暴露公网。外网部署需要HTTPS反向代理、进程守护与代理层限流。当前登录限流为单进程内存级，重启会清空。

保存常用筛选、相似器件推荐、详情PDF导出、OCR为低优先级未实现项。没有前端页面，也未代替组员D完成真实数据准确率验收。运行报告明确列出实测覆盖与限制。

## 资料

- [Flask文件上传与大小限制](https://flask.palletsprojects.com/en/stable/patterns/fileuploads/)
- [Python sqlite3事务及备份](https://docs.python.org/3/library/sqlite3.html)
- [Chat Completions接口说明](https://platform.openai.com/docs/api-reference/chat/create)

实现代码为本项目新写；没有复制第三方业务源码。依赖采用其原有开源许可。
