import json
from flask import Blueprint,g,request
from .auth import login_required
from .common import APIError,body,ok,pagination,text
from .db import dump,get_db,log
from .normalization import normalize_component
from .tasks import serialize_task,task_access

bp=Blueprint('audit',__name__,url_prefix='/api/audit')


@bp.get('/tasks')
@login_required('admin','auditor')
def listing():
    page,size=pagination();db=get_db()
    total=db.execute("SELECT COUNT(*) FROM tasks WHERE status='success' AND review_status='pending' AND deleted=0").fetchone()[0]
    rows=db.execute("SELECT * FROM tasks WHERE status='success' AND review_status='pending' AND deleted=0 ORDER BY task_id LIMIT ? OFFSET ?",(size,(page-1)*size))
    return ok({'items':[serialize_task(r) for r in rows],'total':total,'page':page,'page_size':size})


@bp.get('/tasks/<int:task_id>')
@login_required('admin','auditor')
def detail(task_id):return ok(serialize_task(task_access(task_id),True))


@bp.post('/tasks/<int:task_id>')
@login_required('admin','auditor')
def review(task_id):
    data=body();action=data.get('action')
    if action not in ('approve','reject'):raise APIError('action must be approve or reject')
    comment=text(data.get('comment',''),'comment',2000,required=False)
    if action=='reject' and not comment:raise APIError('Rejection requires a comment')
    db=get_db()
    with db:
        db.execute('BEGIN IMMEDIATE')
        task=task_access(task_id)
        if task['status']!='success' or task['review_status']!='pending':raise APIError('Task is not awaiting review',409)
        original=json.loads(task['result_json'])
        snapshot={'original':original,'submitted_corrections':data.get('components')}
        ids=[]
        if action=='approve':
            if task['base_revision'] is not None and task['component_id'] is None:
                raise APIError('Update target was deleted; create a new task explicitly',409)
            records=data.get('components',original['components'])
            if not isinstance(records,list) or len(records)!=len(original['components']):
                raise APIError('Review must keep the original component count')
            records=[normalize_component(c,{'type':task['source_type'],'location':task['source_location'] if task['source_type']=='url' else task['original_filename'] or 'manual','sha256':task['source_sha256'],'task_id':task_id},False) for c in records]
            identities=set()
            for item in records:
                identity=(item['manufacturer'].casefold(),item['model'].casefold())
                if identity in identities:raise APIError('Duplicate manufacturer/model in review')
                identities.add(identity)
                manufacturer=db.execute('SELECT * FROM manufacturers WHERE name=?',(item['manufacturer'],)).fetchone()
                if manufacturer is None:
                    # Aliases collapse to the existing canonical manufacturer.
                    manufacturer=db.execute('SELECT * FROM manufacturers WHERE EXISTS(SELECT 1 FROM json_each(aliases_json) WHERE value=? COLLATE NOCASE)',(item['manufacturer'],)).fetchone()
                if manufacturer is None:
                    mid=db.execute('INSERT INTO manufacturers(name) VALUES(?)',(item['manufacturer'],)).lastrowid
                else:mid=manufacturer['manufacturer_id']
                existing=db.execute('SELECT * FROM components WHERE manufacturer_id=? AND model=?',(mid,item['model'])).fetchone()
                if task['component_id'] is not None:
                    target=db.execute('SELECT * FROM components WHERE component_id=?',(task['component_id'],)).fetchone()
                    if target is None:raise APIError('Update target was deleted',409)
                    if target['revision']!=task['base_revision']:raise APIError('Component changed since draft creation; create a fresh update',409)
                    if existing and existing['component_id']!=target['component_id']:raise APIError('Manufacturer/model already exists',409)
                    existing=target
                elif existing:
                    if data.get('confirm_overwrite') is not True:raise APIError('Manufacturer/model exists; confirm_overwrite=true required',409)
                    expected=data.get('expected_revisions',{}).get(str(existing['component_id'])) if isinstance(data.get('expected_revisions',{}),dict) else None
                    if expected!=existing['revision']:raise APIError('Supply current expected_revisions to avoid overwriting a concurrent update',409)
                    if db.execute('SELECT role FROM users WHERE user_id=?',(task['user_id'],)).fetchone()['role']=='user' and existing['owner_id']!=task['user_id']:
                        raise APIError('Task creator cannot overwrite another user component',403)
                if existing:
                    cid=existing['component_id']
                    db.execute('UPDATE components SET model=?,manufacturer_id=?,category=?,revision=revision+1,updated_time=CURRENT_TIMESTAMP WHERE component_id=?',(item['model'],mid,item['category'],cid))
                    db.execute('DELETE FROM parameters WHERE component_id=?',(cid,))
                else:
                    cid=db.execute('INSERT INTO components(model,category,manufacturer_id,owner_id) VALUES(?,?,?,?)',(item['model'],item['category'],mid,task['user_id'])).lastrowid
                for p in item['parameters']:
                    db.execute('INSERT INTO parameters(component_id,parameter_name,value_num,value_text,unit,confidence,source_json,task_id) VALUES(?,?,?,?,?,?,?,?)',(cid,p['name'],p['value_num'],p['value_text'],p['unit'],p['confidence'],dump(p['source']),task_id))
                ids.append(cid)
                revision=db.execute('SELECT revision FROM components WHERE component_id=?',(cid,)).fetchone()[0]
                db.execute('INSERT INTO component_tasks(component_id,task_id,revision) VALUES(?,?,?)',(cid,task_id,revision))
            snapshot['published']=records
            db.execute('UPDATE tasks SET component_id=? WHERE task_id=?',(ids[0] if len(ids)==1 else None,task_id))
        db.execute('UPDATE tasks SET review_status=?,action=?,action_time=CURRENT_TIMESTAMP WHERE task_id=?',('approved' if action=='approve' else 'rejected',action,task_id))
        db.execute('INSERT INTO audit_logs(user_id,task_id,action,comment,snapshot_json) VALUES(?,?,?,?,?)',(g.user['user_id'],task_id,action,comment,dump(snapshot)))
        log(db,g.user['user_id'],action,'task',task_id,{'component_ids':ids,'comment':comment})
    return ok({'task_id':task_id,'review_status':'approved' if action=='approve' else 'rejected','component_ids':ids})


@bp.get('/logs')
@login_required('admin','auditor')
def logs():
    page,size=pagination();db=get_db();args=[];where='1=1'
    if request.args.get('task_id'):
        from .common import integer
        where='task_id=?';args=[integer(request.args['task_id'],'task_id')]
    rows=db.execute('SELECT * FROM audit_logs WHERE '+where+' ORDER BY audit_log_id DESC LIMIT ? OFFSET ?',args+[size,(page-1)*size])
    items=[]
    for row in rows:
        item=dict(row);item['snapshot']=json.loads(item.pop('snapshot_json'))
        # Snapshot uses original evidence. Replace local upload storage paths for API clients.
        for key in ('original','published'):
            records=item['snapshot'].get(key)
            if isinstance(records,dict):records=records.get('components',[])
            if not isinstance(records,list):continue
            for c in records:
                for p in c.get('parameters',[]):
                    source=p.get('source',{})
                    if source.get('type') in ('pdf','csv','excel'):source['location']=source.get('filename','uploaded file')
        items.append(item)
    return ok({'items':items,'total':db.execute('SELECT COUNT(*) FROM audit_logs WHERE '+where,args).fetchone()[0],'page':page,'page_size':size})
