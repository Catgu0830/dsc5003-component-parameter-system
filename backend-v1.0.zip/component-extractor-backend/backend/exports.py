import csv
import io
import json
from flask import Blueprint,request,send_file,g
from openpyxl import Workbook
from .auth import login_required
from .common import APIError
from .components import query_components,comparison
from .db import get_db,log

bp=Blueprint('exports',__name__,url_prefix='/api/export')


def safe_cell(value):
    if isinstance(value,str) and value.lstrip().startswith(('=','+','-','@','\t','\r')):
        return "'"+value
    return value


def export_data(data,compare=False):
    format=request.args.get('format','csv').lower()
    if format not in ('json','csv','xlsx','excel'):raise APIError('format must be csv, xlsx or json')
    if format=='json':
        buf=io.BytesIO(json.dumps(data,ensure_ascii=False,allow_nan=False,indent=2).encode('utf-8'))
        mime,extension='application/json','json'
    else:
        components=data['components'] if compare else data['items']
        names=sorted({p['name'] for c in components for p in c['parameters']})
        rows=[['component_id','model','manufacturer','category']+[label for n in names for label in (n,n+'_unit')]]
        for c in components:
            params={p['name']:p for p in c['parameters']}
            row=[c['component_id'],c['model'],c['manufacturer'],c['category']]
            for n in names:
                param=params.get(n)
                row.extend([param['value'],param['unit']] if param else [None,None])
            rows.append([safe_cell(v) for v in row])
        if format=='csv':
            stream=io.StringIO(newline='');writer=csv.writer(stream);writer.writerows(rows)
            buf=io.BytesIO(stream.getvalue().encode('utf-8-sig'));mime,extension='text/csv','csv'
        else:
            book=Workbook();sheet=book.active;sheet.title='Comparison' if compare else 'Components'
            for row in rows:sheet.append(row)
            sheet.freeze_panes='E2';sheet.auto_filter.ref=sheet.dimensions
            buf=io.BytesIO();book.save(buf);mime,extension='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','xlsx'
    db=get_db()
    with db:log(db,g.user['user_id'],'export','comparison' if compare else 'components',details={'format':extension})
    buf.seek(0)
    return send_file(buf,mimetype=mime,as_attachment=True,download_name=('comparison' if compare else 'components')+'.'+extension)


@bp.get('/components')
@login_required()
def components():return export_data(query_components(True))


@bp.get('/compare')
@login_required()
def compare():return export_data(comparison(),True)
