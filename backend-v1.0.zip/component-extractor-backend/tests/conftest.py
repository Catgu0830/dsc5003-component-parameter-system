import pytest
from werkzeug.security import generate_password_hash
from backend import create_app
from backend.db import connect

@pytest.fixture
def app(tmp_path):
    app=create_app({'TESTING':True,'DATABASE':str(tmp_path/'test.db'),'UPLOAD_DIR':str(tmp_path/'uploads'),'EXTRACTION_MODE':'rules','LLM_API_KEY':'','LLM_MODEL':'','MAX_CONTENT_LENGTH':1024*1024,'MAX_RETRIES':2})
    with connect(app.config['DATABASE']) as db:
        for username,role in [('admin','admin'),('auditor','auditor'),('alice','user'),('bob','user')]:
            db.execute('INSERT INTO users(username,password_hash,role) VALUES(?,?,?)',(username,generate_password_hash('TestPass123!'),role))
    return app

@pytest.fixture
def client(app):return app.test_client()

@pytest.fixture
def tokens(client):
    return {name:client.post('/api/auth/login',json={'username':name,'password':'TestPass123!'}).json['data']['token'] for name in ('admin','auditor','alice','bob')}

def headers(tokens,name='alice'):
    return {'Authorization':'Bearer '+tokens[name]}

def component(model='TEST-R',voltage='3300mV'):
    return {'model':model,'manufacturer':'Test Manufacturer','category':'resistor','parameters':[{'name':'工作电压','value':voltage,'confidence':1},{'name':'Resistance','value':'10kΩ'},{'name':'package','value':'0603'}]}

def draft(client,tokens,data=None,name='alice'):
    response=client.post('/api/tasks',json={'component':data or component()},headers=headers(tokens,name))
    assert response.status_code==202,response.json
    return response.json['data']['task_id']

def publish(app,client,tokens,data=None,name='alice'):
    from backend.worker import process_one
    task=draft(client,tokens,data,name);assert process_one(app)
    response=client.post(f'/api/audit/tasks/{task}',json={'action':'approve'},headers=headers(tokens,'auditor'))
    assert response.status_code==200,response.json
    return task,response.json['data']['component_ids'][0]
