import json
import sqlite3
from contextlib import closing
from pathlib import Path
from flask import current_app, g


def connect(path):
    db = sqlite3.connect(path, timeout=15)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('PRAGMA busy_timeout=15000')
    return db


def get_db():
    if 'db' not in g:
        g.db = connect(current_app.config['DATABASE'])
    return g.db


def init_db(path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with closing(connect(path)) as db, db:
        db.execute('PRAGMA journal_mode=WAL')
        db.executescript(Path(__file__).with_name('schema.sql').read_text(encoding='utf-8'))


def dump(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False)


def log(db, actor, action, resource, resource_id=None, details=None):
    db.execute('INSERT INTO operation_logs(user_id,action,resource_type,resource_id,details_json) VALUES(?,?,?,?,?)',
               (actor, action, resource, str(resource_id) if resource_id is not None else None, dump(details or {})))
