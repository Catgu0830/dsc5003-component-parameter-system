import json
from flask import Blueprint,g,request
from werkzeug.security import generate_password_hash
from .auth import login_required,public_user
from .common import APIError,body,integer,ok,pagination,text
from .db import dump,get_db,log

bp=Blueprint('admin',__name__,url_prefix='/api')


@bp.get('/users')
@login_required('admin')
def users():
    page,size=pagination();db=get_db()
    return ok({'items':[public_user(r) for r in db.execute('SELECT * FROM users ORDER BY user_id LIMIT ? OFFSET ?',(size,(page-1)*size))],'total':db.execute('SELECT COUNT(*) FROM users').fetchone()[0],'page':page,'page_size':size})


@bp.post('/users')
@login_required('admin')
def create_user():
    data=body();username=text(data.get('username'),'username',50);password=text(data.get('password'),'password',256)
    role=data.get('role','user')
    if role not in ('admin','auditor','user') or len(password)<8:raise APIError('Valid role and password of at least 8 characters required')
    db=get_db()
    with db:
        uid=db.execute('INSERT INTO users(username,password_hash,role) VALUES(?,?,?)',(username,generate_password_hash(password),role)).lastrowid
        log(db,g.user['user_id'],'create_user','user',uid)
    return ok(public_user(db.execute('SELECT * FROM users WHERE user_id=?',(uid,)).fetchone()),201)


@bp.put('/users/<int:user_id>')
@login_required('admin')
def update_user(user_id):
    data=body();db=get_db()
    with db:
        db.execute('BEGIN IMMEDIATE');row=db.execute('SELECT * FROM users WHERE user_id=?',(user_id,)).fetchone()
        if not row:raise APIError('User not found',404)
        role=data.get('role',row['role']);disabled=data.get('disabled',bool(row['disabled']))
        if role not in ('admin','auditor','user') or not isinstance(disabled,bool):raise APIError('Invalid role or disabled flag')
        if row['role']=='admin' and not row['disabled'] and (role!='admin' or disabled):
            if db.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND disabled=0").fetchone()[0]<=1:
                raise APIError('Cannot disable or demote the last active administrator',409)
        db.execute('UPDATE users SET role=?,disabled=? WHERE user_id=?',(role,int(disabled),user_id))
        if 'password' in data:
            password=text(data['password'],'password',256)
            if len(password)<8:raise APIError('Password too short')
            db.execute('UPDATE users SET password_hash=? WHERE user_id=?',(generate_password_hash(password),user_id))
        if role!=row['role'] or disabled or 'password' in data:db.execute('DELETE FROM tokens WHERE user_id=?',(user_id,))
        log(db,g.user['user_id'],'update_user','user',user_id,{'role':role,'disabled':disabled})
    return ok(public_user(db.execute('SELECT * FROM users WHERE user_id=?',(user_id,)).fetchone()))


@bp.get('/manufacturers')
@login_required()
def manufacturers():
    page,size=pagination();db=get_db()
    rows=[]
    for row in db.execute('SELECT * FROM manufacturers ORDER BY name LIMIT ? OFFSET ?',(size,(page-1)*size)):
        item=dict(row);item['aliases']=json.loads(item.pop('aliases_json'));rows.append(item)
    return ok({'items':rows,'total':db.execute('SELECT COUNT(*) FROM manufacturers').fetchone()[0],'page':page,'page_size':size})


@bp.post('/manufacturers')
@login_required('admin','auditor')
def create_manufacturer():return save_manufacturer()


@bp.put('/manufacturers/<int:manufacturer_id>')
@login_required('admin','auditor')
def update_manufacturer(manufacturer_id):return save_manufacturer(manufacturer_id)


def save_manufacturer(mid=None):
    data=body();name=text(data.get('name'),'name',100);website=data.get('website');aliases=data.get('aliases',[])
    if website is not None:
        website=text(website,'website',500,False)
        if website and not website.startswith(('https://','http://')):raise APIError('website must be HTTP(S)')
    if not isinstance(aliases,list) or len(aliases)>20:raise APIError('At most 20 manufacturer aliases')
    aliases=[text(x,'alias',100) for x in aliases]
    if len({x.casefold() for x in [name]+aliases})!=1+len(aliases):raise APIError('Duplicate aliases')
    db=get_db()
    with db:
        db.execute('BEGIN IMMEDIATE')
        if mid and not db.execute('SELECT 1 FROM manufacturers WHERE manufacturer_id=?',(mid,)).fetchone():raise APIError('Manufacturer not found',404)
        for row in db.execute('SELECT * FROM manufacturers WHERE manufacturer_id!=?',(mid or -1,)):
            other={row['name'].casefold(),*[a.casefold() for a in json.loads(row['aliases_json'])]}
            if other.intersection({name.casefold(),*[a.casefold() for a in aliases]}):raise APIError('Manufacturer name/alias conflicts with an existing manufacturer',409)
        if mid:db.execute('UPDATE manufacturers SET name=?,website=?,aliases_json=? WHERE manufacturer_id=?',(name,website,dump(aliases),mid))
        else:mid=db.execute('INSERT INTO manufacturers(name,website,aliases_json) VALUES(?,?,?)',(name,website,dump(aliases))).lastrowid
        log(db,g.user['user_id'],'save','manufacturer',mid)
    return ok({'manufacturer_id':mid,'name':name,'website':website,'aliases':aliases})


@bp.get('/logs')
@login_required('admin')
def logs():
    page,size=pagination();db=get_db()
    items=[]
    for row in db.execute('SELECT * FROM operation_logs ORDER BY log_id DESC LIMIT ? OFFSET ?',(size,(page-1)*size)):
        item=dict(row);item['details']=json.loads(item.pop('details_json'));items.append(item)
    return ok({'items':items,'total':db.execute('SELECT COUNT(*) FROM operation_logs').fetchone()[0],'page':page,'page_size':size})
