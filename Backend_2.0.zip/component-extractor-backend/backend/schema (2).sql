PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
 user_id INTEGER PRIMARY KEY, username TEXT NOT NULL COLLATE NOCASE UNIQUE,
 password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('admin','auditor','user')),
 disabled INTEGER NOT NULL DEFAULT 0 CHECK(disabled IN (0,1)),
 created_time TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, last_login TEXT
);
CREATE TABLE IF NOT EXISTS tokens (
 token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
 expires_at TEXT NOT NULL, created_time TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS manufacturers (
 manufacturer_id INTEGER PRIMARY KEY, name TEXT NOT NULL COLLATE NOCASE UNIQUE, website TEXT,
 aliases_json TEXT NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS components (
 component_id INTEGER PRIMARY KEY, model TEXT NOT NULL COLLATE NOCASE, category TEXT NOT NULL,
 manufacturer_id INTEGER NOT NULL REFERENCES manufacturers(manufacturer_id),
 owner_id INTEGER NOT NULL REFERENCES users(user_id), revision INTEGER NOT NULL DEFAULT 1,
 created_time TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_time TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(manufacturer_id,model)
);
CREATE TABLE IF NOT EXISTS tasks (
 task_id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(user_id),
 component_id INTEGER REFERENCES components(component_id) ON DELETE SET NULL,
 source_type TEXT NOT NULL CHECK(source_type IN ('manual','pdf','url','csv','excel')),
 source_location TEXT NOT NULL, original_filename TEXT, source_sha256 TEXT,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','processing','success','failed','paused','cancelled')),
 review_status TEXT NOT NULL DEFAULT 'pending' CHECK(review_status IN ('pending','approved','rejected')),
 input_json TEXT NOT NULL DEFAULT '{}', result_json TEXT, error_msg TEXT,
 retry_count INTEGER NOT NULL DEFAULT 0, attempt INTEGER NOT NULL DEFAULT 0,
 action TEXT NOT NULL DEFAULT 'create', action_time TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 created_time TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, finished_time TEXT, lease_until TEXT,
 deleted INTEGER NOT NULL DEFAULT 0, base_revision INTEGER
);
CREATE TABLE IF NOT EXISTS parameters (
 component_id INTEGER NOT NULL REFERENCES components(component_id) ON DELETE CASCADE,
 parameter_name TEXT NOT NULL, value_num REAL, value_text TEXT, unit TEXT,
 confidence REAL NOT NULL CHECK(confidence>=0 AND confidence<=1), source_json TEXT NOT NULL,
 task_id INTEGER REFERENCES tasks(task_id) ON DELETE SET NULL,
 PRIMARY KEY(component_id,parameter_name),
 CHECK((value_num IS NOT NULL AND value_text IS NULL) OR (value_num IS NULL AND value_text IS NOT NULL))
);
CREATE TABLE IF NOT EXISTS audit_logs (
 audit_log_id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(user_id),
 task_id INTEGER NOT NULL REFERENCES tasks(task_id), action TEXT NOT NULL CHECK(action IN ('approve','reject')),
 comment TEXT NOT NULL DEFAULT '', snapshot_json TEXT NOT NULL, audit_time TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS operation_logs (
 log_id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(user_id), action TEXT NOT NULL,
 resource_type TEXT NOT NULL, resource_id TEXT, details_json TEXT NOT NULL DEFAULT '{}',
 created_time TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_components_category ON components(category);
CREATE INDEX IF NOT EXISTS idx_components_model ON components(model);
CREATE INDEX IF NOT EXISTS idx_components_owner ON components(owner_id);
CREATE INDEX IF NOT EXISTS idx_parameters_range ON parameters(parameter_name,value_num,component_id);
CREATE INDEX IF NOT EXISTS idx_tasks_owner_status ON tasks(user_id,status,review_status);
CREATE INDEX IF NOT EXISTS idx_tasks_queue ON tasks(status,deleted,task_id);
CREATE INDEX IF NOT EXISTS idx_audit_task ON audit_logs(task_id);
CREATE TABLE IF NOT EXISTS component_tasks (
 component_id INTEGER NOT NULL REFERENCES components(component_id) ON DELETE CASCADE,
 task_id INTEGER NOT NULL REFERENCES tasks(task_id), revision INTEGER NOT NULL,
 PRIMARY KEY(component_id,task_id)
);

CREATE TABLE IF NOT EXISTS specifications (
 specification_id INTEGER PRIMARY KEY,
 component_id INTEGER NOT NULL REFERENCES components(component_id) ON DELETE CASCADE,
 task_id INTEGER REFERENCES tasks(task_id),
 record_json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_specifications_component ON specifications(component_id);
