import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from functools import wraps
from flask import Blueprint, current_app, g, request
from werkzeug.security import check_password_hash, generate_password_hash
from .common import APIError, body, ok, text
from .db import get_db, log

bp = Blueprint('auth', __name__, url_prefix='/api/auth')


def hash_token(token):
    return hashlib.sha256(token.encode()).hexdigest()


def utc():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def public_user(row):
    return {k: row[k] for k in ('user_id', 'username', 'role', 'disabled', 'created_time', 'last_login')}


def login_required(*roles):
    def decorator(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            header = request.headers.get('Authorization', '')
            if not header.startswith('Bearer ') or len(header) > 500:
                raise APIError('Bearer token required', 401)
            token_hash = hash_token(header[7:])
            user = get_db().execute('SELECT u.* FROM tokens t JOIN users u USING(user_id) WHERE t.token_hash=? AND t.expires_at>? AND u.disabled=0', (token_hash, utc())).fetchone()
            if user is None:
                raise APIError('Token invalid or expired', 401)
            g.user, g.token_hash = user, token_hash
            if roles and user['role'] not in roles:
                raise APIError('Insufficient role', 403)
            return fn(*args, **kwargs)
        return wrapped
    return decorator


@bp.post('/register')
def register():
    data = body()
    username = text(data.get('username'), 'username', 50)
    password = text(data.get('password'), 'password', 256)
    if len(password) < 8:
        raise APIError('Password must contain at least 8 characters')
    if data.get('role', 'user') != 'user':
        raise APIError('Public registration cannot assign privileged roles', 403)
    db = get_db()
    with db:
        cursor = db.execute('INSERT INTO users(username,password_hash) VALUES(?,?)', (username, generate_password_hash(password)))
        log(db, cursor.lastrowid, 'register', 'user', cursor.lastrowid)
    return ok(public_user(db.execute('SELECT * FROM users WHERE user_id=?', (cursor.lastrowid,)).fetchone()), 201)


@bp.post('/login')
def login():
    data = body()
    username = text(data.get('username'), 'username', 50)
    password = text(data.get('password'), 'password', 256)
    db = get_db()
    user = db.execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()
    # Bounded in-memory throttle is supplemented by a reverse proxy for Internet deployments.
    key = (request.remote_addr or '', username.casefold())
    import time
    state = current_app.extensions['login_attempts']
    now = time.monotonic()
    recent = [t for t in state.get(key, []) if now-t < 300]
    if len(recent) >= 10:
        raise APIError('Too many login attempts; try again in 5 minutes', 429)
    if user is None or user['disabled'] or not check_password_hash(user['password_hash'], password):
        if len(state) > 10000:
            state.clear()
        state[key] = recent + [now]
        raise APIError('Invalid username or password', 401)
    state.pop(key, None)
    token = secrets.token_urlsafe(32)
    expires = (datetime.now(timezone.utc)+timedelta(hours=current_app.config['TOKEN_HOURS'])).isoformat(timespec='seconds')
    with db:
        db.execute('DELETE FROM tokens WHERE expires_at<=?', (utc(),))
        db.execute('INSERT INTO tokens(token_hash,user_id,expires_at) VALUES(?,?,?)', (hash_token(token), user['user_id'], expires))
        db.execute('UPDATE users SET last_login=CURRENT_TIMESTAMP WHERE user_id=?', (user['user_id'],))
        log(db, user['user_id'], 'login', 'user', user['user_id'])
    return ok({'token': token, 'token_type': 'Bearer', 'expires_at': expires, 'user': public_user(db.execute('SELECT * FROM users WHERE user_id=?', (user['user_id'],)).fetchone())})


@bp.get('/me')
@login_required()
def me():
    return ok(public_user(g.user))


@bp.post('/logout')
@login_required()
def logout():
    db = get_db()
    with db:
        db.execute('DELETE FROM tokens WHERE token_hash=?', (g.token_hash,))
        log(db, g.user['user_id'], 'logout', 'user', g.user['user_id'])
    return ok()
