import json
from flask import Blueprint,g,request
from .auth import login_required
from .common import APIError,body,confirmed,integer,ok,pagination
from .db import get_db,log
from .normalization import BASE_UNITS,canonical_name,category,numeric
from .tasks import create_task,serialize_task

bp=Blueprint('components',__name__,url_prefix='/api/components')


def component_access(component_id,edit=False):
    row=get_db().execute('SELECT c.*,m.name AS manufacturer,m.website FROM components c JOIN manufacturers m USING(manufacturer_id) WHERE component_id=?',(component_id,)).fetchone()
    if row is None:raise APIError('Component not found',404)
    if g.user['role']=='user' and row['owner_id']!=g.user['user_id']:
        raise APIError('Component belongs to another user',403)
    return row


def serialize_component(row):
    result=dict(row)
    parameters=[]
    for p in get_db().execute('SELECT * FROM parameters WHERE component_id=? ORDER BY parameter_name',(row['component_id'],)):
        p=dict(p)
        parameters.append({'name':p['parameter_name'],'value':p['value_num'] if p['value_num'] is not None else p['value_text'],'value_num':p['value_num'],'value_text':p['value_text'],'unit':p['unit'],'confidence':p['confidence'],'source':json.loads(p['source_json']),'task_id':p['task_id']})
    result['parameters']=parameters
    result['specifications']=[dict(json.loads(r['record_json']),specification_id=r['specification_id'],task_id=r['task_id']) for r in get_db().execute('SELECT * FROM specifications WHERE component_id=? ORDER BY specification_id',(row['component_id'],))]
    return result


def filters(query=None):
    query=request.args if query is None else query
    where=['1=1'];args=[]
    if g.user['role']=='user':where.append('c.owner_id=?');args.append(g.user['user_id'])
    if query.get('component_id'):
        where.append('c.component_id=?');args.append(integer(query['component_id'],'component_id'))
    keyword=query.get('keyword',query.get('q',''))
    if not isinstance(keyword,str):raise APIError('keyword must be a string')
    keyword=keyword.strip()
    if keyword:
        if len(keyword)>200:raise APIError('keyword too long')
        where.append("(c.model LIKE ? ESCAPE '\\' OR m.name LIKE ? ESCAPE '\\' OR EXISTS(SELECT 1 FROM json_each(m.aliases_json) a WHERE a.value LIKE ? ESCAPE '\\') OR EXISTS(SELECT 1 FROM parameters p WHERE p.component_id=c.component_id AND p.parameter_name='package' AND p.value_text LIKE ? ESCAPE '\\') OR EXISTS(SELECT 1 FROM specifications s WHERE s.component_id=c.component_id AND s.record_json LIKE ? ESCAPE '\\'))")
        pattern='%'+keyword.replace('\\','\\\\').replace('%','\\%').replace('_','\\_')+'%'
        args.extend([pattern]*5)
    if query.get('category'):where.append('c.category=?');args.append(category(query['category']))
    if query.get('manufacturer_id'):where.append('c.manufacturer_id=?');args.append(integer(query['manufacturer_id'],'manufacturer_id'))
    if query.get('manufacturer'):
        if not isinstance(query['manufacturer'],str):raise APIError('manufacturer must be a string')
        where.append('(m.name=? COLLATE NOCASE OR EXISTS(SELECT 1 FROM json_each(m.aliases_json) a WHERE a.value=? COLLATE NOCASE))');args.extend([query['manufacturer']]*2)
    if query.get('package'):
        if not isinstance(query['package'],str):raise APIError('package must be a string')
        where.append("EXISTS(SELECT 1 FROM parameters p WHERE p.component_id=c.component_id AND p.parameter_name='package' AND p.value_text=?)");args.append(query['package'].upper().replace(' ',''))
    raw=query.get('filters','[]')
    try:ranges=raw if isinstance(raw,list) else json.loads(raw)
    except (ValueError,TypeError):raise APIError('filters must be a JSON array')
    if not isinstance(ranges,list) or len(ranges)>10:raise APIError('At most 10 range filters')
    # All conditions use EXISTS, avoiding duplicate component rows and enforcing AND semantics.
    for condition in ranges:
        if not isinstance(condition,dict):raise APIError('Each filter must be an object')
        name=canonical_name(condition.get('name'))
        if name not in BASE_UNITS:raise APIError('Numeric ranges support standardized parameters: '+', '.join(BASE_UNITS))
        checks=['p.component_id=c.component_id','p.parameter_name=?','p.value_num IS NOT NULL'];values=[name]
        bounds={}
        for key,op in (('min','>='),('max','<=')):
            if key in condition:
                value,unit=numeric(condition[key],condition.get('unit'),name)
                bounds[key]=value;checks.append(f'p.value_num{op}?');values.append(value)
        if not bounds:raise APIError('Range filter needs min or max')
        if bounds.get('min',float('-inf'))>bounds.get('max',float('inf')):raise APIError('min cannot exceed max')
        where.append('EXISTS(SELECT 1 FROM parameters p WHERE '+' AND '.join(checks)+')');args.extend(values)
    required=query.get('required_parameters',[])
    if not isinstance(required,list) or len(required)>20:raise APIError('required_parameters must be an array of at most 20 names')
    for name in required:
        where.append('EXISTS(SELECT 1 FROM parameters p WHERE p.component_id=c.component_id AND p.parameter_name=?)');args.append(canonical_name(name))
    return ' AND '.join(where),args


def query_components(export=False,query=None):
    query=request.args if query is None else query
    page,size=pagination(query);where,args=filters(query)
    sort=query.get('sort','component_id')
    allowed={'component_id':'c.component_id','model':'c.model','category':'c.category','manufacturer':'m.name','created_time':'c.created_time'}
    order=query.get('order','desc')
    if not isinstance(order,str):raise APIError('order must be a string')
    order=order.lower()
    if not isinstance(sort,str):raise APIError('sort must be a string')
    if sort not in allowed or order not in ('asc','desc'):raise APIError('Unsupported sort/order')
    db=get_db();base=' FROM components c JOIN manufacturers m USING(manufacturer_id) WHERE '+where
    total=db.execute('SELECT COUNT(*)'+base,args).fetchone()[0]
    if export and total>10000:raise APIError('Export limited to 10000 components; narrow filters')
    limit,offset=(10000,0) if export else (size,(page-1)*size)
    rows=db.execute('SELECT c.*,m.name AS manufacturer,m.website'+base+f' ORDER BY {allowed[sort]} {order},c.component_id {order} LIMIT ? OFFSET ?',args+[limit,offset]).fetchall()
    return {'items':[serialize_component(row) for row in rows],'total':total,'page':page,'page_size':size}


@bp.get('')
@login_required()
def listing():return ok(query_components())


@bp.post('')
@login_required()
def create():
    data=body()
    row=create_task({'source_type':'manual','component':data})
    return ok({'task':serialize_task(row),'publication':'pending_review'},202)


@bp.get('/<int:component_id>')
@login_required()
def detail(component_id):
    item=serialize_component(component_access(component_id))
    item['history']=[dict(r) for r in get_db().execute('SELECT t.task_id,t.source_type,t.status,t.review_status,t.created_time,ct.revision FROM tasks t JOIN component_tasks ct USING(task_id) WHERE ct.component_id=? AND t.deleted=0 ORDER BY t.task_id DESC',(component_id,))]
    return ok(item)


@bp.put('/<int:component_id>')
@login_required()
def update(component_id):
    row=component_access(component_id,True);data=body()
    current=serialize_component(row)
    current.update({k:v for k,v in data.items() if k in ('model','manufacturer','category','parameters','specifications')})
    task=create_task({'component':current},component_id,row['revision'])
    return ok({'task':serialize_task(task),'publication':'pending_review'},202)


@bp.delete('/<int:component_id>')
@login_required('admin')
def delete(component_id):
    confirmed(body());db=get_db()
    with db:
        db.execute('BEGIN IMMEDIATE');component_access(component_id)
        db.execute('DELETE FROM components WHERE component_id=?',(component_id,))
        log(db,g.user['user_id'],'delete','component',component_id)
    return ok()


@bp.get('/<int:component_id>/parameters')
@login_required()
def parameters(component_id):return ok(serialize_component(component_access(component_id))['parameters'])


@bp.post('/<int:component_id>/parameters')
@login_required()
def add_parameters(component_id):
    row=component_access(component_id,True);data=body()
    incoming=data.get('parameters',[data] if 'name' in data or 'parameter_name' in data else None)
    if not isinstance(incoming,list):raise APIError('parameters must be an array')
    current=serialize_component(row)
    mapped={p['name']:p for p in current['parameters']}
    for p in incoming:
        if not isinstance(p,dict):raise APIError('Parameter must be an object')
        name=canonical_name(p.get('name',p.get('parameter_name')));mapped[name]={**p,'name':name}
    current['parameters']=list(mapped.values())
    task=create_task({'component':current},component_id,row['revision'])
    return ok({'task':serialize_task(task),'publication':'pending_review'},202)


def comparison():
    raw=request.args.get('ids','').split(',')
    if not 2<=len(raw)<=10:raise APIError('Compare requires 2-10 component ids')
    ids=[integer(x,'id') for x in raw]
    if len(set(ids))!=len(ids):raise APIError('Comparison ids must be unique')
    items=[serialize_component(component_access(x)) for x in ids]
    names=sorted({p['name'] for c in items for p in c['parameters']})
    maps=[{p['name']:p for p in c['parameters']} for c in items]
    rows=[]
    for name in names:
        values=[params.get(name) for params in maps]
        comparable=[(x['value'],x['unit']) if x else None for x in values]
        rows.append({'name':name,'values':values,'missing_component_ids':[ids[i] for i,p in enumerate(values) if p is None], 'different':any(v!=comparable[0] for v in comparable[1:])})
    return {'components':items,'rows':rows}


@bp.get('/compare')
@login_required()
def compare():return ok(comparison())
