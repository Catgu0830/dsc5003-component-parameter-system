"""Unit normalization shared by extraction, review and numeric filtering."""
import math
import re
from decimal import Decimal
from .common import APIError, text

ALIASES = {
    'voltage': ('voltage', 'v', '工作电压', '电压', '额定电压'),
    'current': ('current', 'i', '电流', '工作电流', '额定电流'),
    'resistance': ('resistance', 'r', '电阻', '阻值'),
    'capacitance': ('capacitance', 'c', '电容', '容值'),
    'frequency': ('frequency', 'freq', '频率'),
    'tolerance': ('tolerance', '容差', '精度'),
    'package': ('package', '封装', '封装形式'),
    'power': ('power', '功率', '额定功率'),
}
LOOKUP = {a.casefold(): name for name, aliases in ALIASES.items() for a in aliases}
CATEGORIES = {'电阻': 'resistor', '电容': 'capacitor', '二极管': 'diode', '三极管': 'transistor', '芯片': 'ic', 'chip': 'ic', 'inductor': 'inductor', '电感': 'inductor', 'other': 'other'}
BASE_UNITS = {'voltage': 'V', 'current': 'A', 'resistance': 'Ω', 'capacitance': 'F', 'frequency': 'Hz', 'tolerance': '%', 'power': 'W'}
PREFIX = {'p': 1e-12, 'n': 1e-9, 'u': 1e-6, 'µ': 1e-6, 'μ': 1e-6, 'm': 1e-3, '': 1, 'k': 1e3, 'K': 1e3, 'M': 1e6, 'G': 1e9}
NUMBER = re.compile(r'^\s*([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)\s*(.*?)\s*$')


def canonical_name(name):
    name = text(name, 'parameter_name', 50)
    return LOOKUP.get(name.casefold(), name.lower())


def category(value):
    value = text(value, 'category', 50).lower()
    value = CATEGORIES.get(value, value)
    if value not in {'resistor', 'capacitor', 'diode', 'transistor', 'ic', 'inductor', 'other'}:
        raise APIError('Unsupported category; use resistor/capacitor/diode/transistor/ic/inductor/other')
    return value


def numeric(value, unit, name, allow_missing_unit=False):
    if isinstance(value, bool):
        raise APIError('Boolean is not a numeric parameter')
    match = NUMBER.fullmatch(str(value))
    if not match:
        raise APIError(f'{name} requires a scalar number; ranges/typ/min/max must be entered separately')
    raw_unit = match[2]
    if unit is not None and not isinstance(unit, str):
        raise APIError('unit must be a string')
    if raw_unit and unit and raw_unit != unit:
        raise APIError('Conflicting inline unit and unit field')
    unit = (unit or raw_unit or '').strip()
    number = float(match[1])
    if not math.isfinite(number):
        raise APIError('Numeric parameter must be finite')
    base = BASE_UNITS.get(name)
    if not base:
        return number, unit or None
    if not unit:
        if not allow_missing_unit:
            raise APIError(f'{name}: unit is required')
        return number, None
    unit = unit.replace('ohms', 'Ω').replace('ohm', 'Ω').replace('Ohm', 'Ω').replace('Ω', 'Ω').replace('欧姆', 'Ω').replace('伏', 'V').replace('安', 'A').replace('赫兹', 'Hz')
    if unit == base:
        factor = 1
    elif base != '%' and unit.endswith(base) and unit[:-len(base)] in PREFIX:
        factor = PREFIX[unit[:-len(base)]]
    else:
        raise APIError(f'Unit {unit!r} is incompatible with {name}; expected {base} or an SI-prefixed unit')
    # Decimal multiplication prevents 3300mV becoming 3.3000000000000003V
    # and incorrectly excluding an exactly equal 3.3V lower-bound filter.
    number = float(Decimal(match[1]) * Decimal(str(factor)))
    if not math.isfinite(number):
        raise APIError('Normalized number overflows')
    return number, base


def normalize_parameter(p, source=None, allow_missing_unit=False):
    if not isinstance(p, dict):
        raise APIError('Each parameter must be an object')
    if p.get('source') is not None and not isinstance(p['source'],dict):
        raise APIError('source must be an object')
    evidence=p.get('source') or {}
    for key in ('page','row'):
        if key in evidence and (isinstance(evidence[key],bool) or not isinstance(evidence[key],int) or evidence[key]<1):
            raise APIError(f'source.{key} must be a positive integer')
    if 'snippet' in evidence and (not isinstance(evidence['snippet'],str) or len(evidence['snippet'])>4000):
        raise APIError('source.snippet must be a string of at most 4000 characters')
    name = canonical_name(p.get('name', p.get('parameter_name')))
    value = p.get('value', p.get('parameter_value'))
    if value is None or value == '':
        return None, [f'{name}: missing value, not stored as zero']
    warnings = []
    unit = p.get('unit')
    if name in BASE_UNITS:
        value_num, unit = numeric(value, unit, name, allow_missing_unit)
        value_text = None
        if not unit:
            warnings.append(f'{name}: missing unit; cannot approve until corrected')
        if value_num < 0:
            warnings.append(f'{name}: negative value; reviewer must confirm its physical meaning')
        if name == 'tolerance' and not 0 <= value_num <= 100:
            warnings.append('tolerance: outside 0-100%')
    elif name == 'package':
        value_num, value_text, unit = None, text(str(value), 'package', 100).upper().replace(' ', ''), None
    elif isinstance(value, (float, int)) and not isinstance(value, bool):
        value_num, unit = numeric(value, unit, name)
        value_text = None
    else:
        value_num, value_text = None, text(str(value), 'parameter value', 500)
    confidence = p.get('confidence', 0.7)
    if isinstance(confidence, bool) or not isinstance(confidence, (int, float)) or not math.isfinite(confidence) or not 0 <= confidence <= 1:
        raise APIError('confidence must be a finite number between 0 and 1')
    provenance = dict(source or p.get('source') or {})
    if source and p.get('source'):
        extra = p['source']
        if not isinstance(extra, dict):
            raise APIError('source must be an object')
        for key in ('page', 'row', 'snippet'):
            if key in extra:
                provenance[key] = extra[key]
    return {'name': name, 'value': value_num if value_num is not None else value_text,
            'value_num': value_num, 'value_text': value_text, 'unit': unit,
            'confidence': float(confidence), 'source': provenance}, warnings


def normalize_component(raw, source=None, allow_missing_unit=False):
    if not isinstance(raw, dict):
        raise APIError('Component must be an object')
    result = {'model': text(raw.get('model'), 'model', 100),
              'manufacturer': text(raw.get('manufacturer'), 'manufacturer', 100),
              'category': category(raw.get('category'))}
    params = raw.get('parameters', [])
    if isinstance(params, dict):
        params = [{'name': k, 'value': v} if not isinstance(v, dict) else {'name': k, **v} for k,v in params.items()]
    if not isinstance(params, list) or len(params) > 100:
        raise APIError('parameters must be a list with at most 100 entries')
    normalized, warnings, seen = [], [], set()
    for p in params:
        item, issues = normalize_parameter(p, source, allow_missing_unit)
        warnings.extend(issues)
        if item:
            if item['name'] in seen:
                raise APIError(f'Duplicate parameter after alias normalization: {item["name"]}')
            seen.add(item['name']); normalized.append(item)
    from .pdf_specs import normalize_specifications
    specs=normalize_specifications(raw.get('specifications',[]))
    if source and source.get('type')=='pdf' and source.get('task_id'):
        for spec in specs:spec['source']['task_id']=source['task_id']
    if not normalized and not specs:raise APIError('Component has no parameters or specifications')
    result.update(parameters=normalized, specifications=specs, warnings=warnings)
    return result
