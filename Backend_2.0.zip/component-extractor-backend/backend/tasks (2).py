import hashlib
import json
import uuid
from pathlib import Path
from flask import Blueprint,current_app,g,request
from werkzeug.utils import secure_filename
from .auth import login_required
from .common import APIError,body,confirmed,ok,pagination,text
from .db import dump,get_db,log
from .normalization import normalize_component
from .sources import check_xlsx,validate_url

bp=Blueprint('tasks',__name__,url_prefix='/api/tasks')


def task_access(task_id):
    row=get_db().execute('SELECT * FROM tasks WHERE task_id=? AND deleted=0',(task_id,)).fetchone()
    if row is None:raise APIError('Task not found',404)
    if g.user['role']=='user' and row['user_id']!=g.user['user_id']:
        raise APIError('Task belongs to another user',403)
    return row


def serialize_task(row,detail=False):
    result={k:row[k] for k in ('task_id','user_id','component_id','source_type','original_filename','source_sha256','status','review_status','error_msg','retry_count','attempt','action','action_time','created_time','finished_time','base_revision')}
    # Internal absolute file paths are never returned. Source downloads use an authorized endpoint.
    result['source_location']=row['source_location'] if row['source_type']=='url' else row['original_filename'] or row['source_type']
    if detail:
        result['result']=json.loads(row['result_json']) if row['result_json'] else None
        if result['result']:
            for c in result['result']['components']:
                for p in c['parameters']:
                    if p['source'].get('type') in ('pdf','csv','excel'):
                        p['source']['location']=row['original_filename']
        result['audit_history']=[dict(x) for x in get_db().execute('SELECT audit_log_id,user_id,action,comment,audit_time FROM audit_logs WHERE task_id=? ORDER BY audit_log_id',(row['task_id'],))]
    return result


def create_task(data,component_id=None,base_revision=None):
    source_type=data.get('source_type','manual')
    if source_type not in ('manual','url'):raise APIError('For PDF/CSV/XLSX use /api/tasks/upload')
    if source_type=='url':
        location=text(data.get('url',data.get('source_location')),'url',2000)
        validate_url(location,current_app.config['URL_ALLOWED_HOSTS'])
        payload={}
    else:
        records=data.get('components',[data.get('component',data)])
        if not isinstance(records,list) or not 1<=len(records)<=1000:raise APIError('Expected 1-1000 components')
        # Fail fast for malformed manual entries. Units required for manual entry.
        records=[normalize_component(c,{'type':'manual','snippet':'User-supplied structured entry'}) for c in records]
        payload={'components':records};location='manual'
    db=get_db()
    with db:
        cursor=db.execute('INSERT INTO tasks(user_id,component_id,source_type,source_location,input_json,base_revision) VALUES(?,?,?,?,?,?)',(g.user['user_id'],component_id,source_type,location,dump(payload),base_revision))
        log(db,g.user['user_id'],'create','task',cursor.lastrowid)
    return db.execute('SELECT * FROM tasks WHERE task_id=?',(cursor.lastrowid,)).fetchone()


@bp.get('')
@login_required()
def list_tasks():
    page,size=pagination(); clauses=['deleted=0'];args=[]
    if g.user['role']=='user':clauses.append('user_id=?');args.append(g.user['user_id'])
    for key in ('status','review_status'):
        if request.args.get(key):clauses.append(f'{key}=?');args.append(request.args[key])
    where=' AND '.join(clauses);db=get_db()
    total=db.execute('SELECT COUNT(*) FROM tasks WHERE '+where,args).fetchone()[0]
    rows=db.execute('SELECT * FROM tasks WHERE '+where+' ORDER BY task_id DESC LIMIT ? OFFSET ?',args+[size,(page-1)*size])
    return ok({'items':[serialize_task(x) for x in rows],'total':total,'page':page,'page_size':size})


@bp.post('')
@login_required()
def post_task():
    row=create_task(body())
    return ok(serialize_task(row),202)


@bp.post('/upload')
@login_required()
def upload():
    file=request.files.get('file')
    if not file or not file.filename:raise APIError('multipart file field is required')
    extension=Path(file.filename).suffix.lower()
    types={'.pdf':'pdf','.csv':'csv','.xlsx':'excel'}
    if extension not in types:raise APIError('Only .pdf, .csv and .xlsx are supported')
    original=secure_filename(file.filename) or ('upload'+extension)
    destination=Path(current_app.config['UPLOAD_DIR'])/(uuid.uuid4().hex+extension)
    file.save(destination)
    try:
        raw=destination.read_bytes()
        if not raw:raise APIError('File is empty')
        if extension=='.pdf' and not raw.startswith(b'%PDF-'):raise APIError('Invalid PDF signature')
        if extension=='.xlsx':check_xlsx(destination)
        if extension=='.csv':
            try:raw.decode('utf-8-sig')
            except UnicodeDecodeError:raise APIError('CSV must be UTF-8 encoded')
            if b'\x00' in raw:raise APIError('Invalid CSV content')
        db=get_db()
        with db:
            cursor=db.execute('INSERT INTO tasks(user_id,source_type,source_location,original_filename,source_sha256) VALUES(?,?,?,?,?)',(g.user['user_id'],types[extension],str(destination),original,hashlib.sha256(raw).hexdigest()))
            log(db,g.user['user_id'],'upload','task',cursor.lastrowid,{'filename':original,'bytes':len(raw)})
        return ok(serialize_task(db.execute('SELECT * FROM tasks WHERE task_id=?',(cursor.lastrowid,)).fetchone()),202)
    except Exception:
        destination.unlink(missing_ok=True)
        raise


@bp.get('/<int:task_id>')
@login_required()
def detail(task_id):
    return ok(serialize_task(task_access(task_id),True))


@bp.get('/<int:task_id>/source')
@login_required()
def source(task_id):
    from flask import send_file
    row=task_access(task_id)
    if row['source_type'] not in ('pdf','csv','excel'):raise APIError('No downloadable source file',404)
    return send_file(row['source_location'],as_attachment=True,download_name=row['original_filename'])


@bp.post('/<int:task_id>/retry')
@login_required()
def retry(task_id):
    db=get_db()
    with db:
        db.execute('BEGIN IMMEDIATE');row=task_access(task_id)
        if row['status']!='failed':raise APIError('Only failed tasks may be retried',409)
        if row['retry_count']>=current_app.config['MAX_RETRIES']:raise APIError('Retry limit reached; create a new task',409)
        db.execute("UPDATE tasks SET status='pending',retry_count=retry_count+1,error_msg=NULL,result_json=NULL,finished_time=NULL,action='retry',action_time=CURRENT_TIMESTAMP WHERE task_id=?",(task_id,))
        log(db,g.user['user_id'],'retry','task',task_id)
    return ok(serialize_task(task_access(task_id)),202)


@bp.post('/<int:task_id>/<action>')
@login_required()
def control(task_id,action):
    if action not in ('pause','resume','terminate'):raise APIError('Unknown action',404)
    db=get_db()
    with db:
        db.execute('BEGIN IMMEDIATE');row=task_access(task_id)
        if row['review_status']!='pending':raise APIError('Reviewed task cannot be controlled',409)
        old=row['status']
        allowed={'pause':('pending',),'resume':('paused',),'terminate':('pending','paused','processing','failed')}
        if old not in allowed[action]:raise APIError('Invalid task state transition',409)
        status={'pause':'paused','resume':'pending','terminate':'cancelled'}[action]
        db.execute('UPDATE tasks SET status=?,action=?,action_time=CURRENT_TIMESTAMP WHERE task_id=?',(status,action,task_id))
        log(db,g.user['user_id'],action,'task',task_id)
    return ok(serialize_task(task_access(task_id)))


@bp.delete('/<int:task_id>')
@login_required('admin')
def delete(task_id):
    confirmed(body());db=get_db()
    with db:
        db.execute('BEGIN IMMEDIATE');task_access(task_id)
        db.execute("UPDATE tasks SET deleted=1,status=CASE WHEN status IN ('pending','processing','paused') THEN 'cancelled' ELSE status END,action='delete',action_time=CURRENT_TIMESTAMP WHERE task_id=?",(task_id,))
        log(db,g.user['user_id'],'delete','task',task_id)
    return ok()


@bp.get('/<int:task_id>/source/page/<int:page_no>')
@login_required()
def source_page(task_id,page_no):
    import io
    import pymupdf
    from flask import send_file
    row=task_access(task_id)
    if row['source_type']!='pdf':raise APIError('Source is not a PDF',400)
    with pymupdf.open(row['source_location']) as doc:
        if doc.needs_pass:raise APIError('PDF requires a password',400)
        if page_no<1 or page_no>len(doc):raise APIError('PDF page not found',404)
        page=doc[page_no-1]
        scale=min(1.5,1800/max(page.rect.width,page.rect.height))
        raw=page.get_pixmap(matrix=pymupdf.Matrix(scale,scale),alpha=False).tobytes('png')
    return send_file(io.BytesIO(raw),mimetype='image/png',download_name=f'page-{page_no}.png')
