"""SQLite-backed queue: processing never runs inside an HTTP request."""
import threading
from datetime import datetime,timedelta,timezone
from .db import connect,dump,log
from .extraction import extract
from .common import APIError


def process_one(app):
    db=connect(app.config['DATABASE'])
    try:
        now=datetime.now(timezone.utc)
        with db:
            db.execute('BEGIN IMMEDIATE')
            db.execute("UPDATE tasks SET status='failed',error_msg='Worker lease expired; retry this task',finished_time=CURRENT_TIMESTAMP,lease_until=NULL WHERE status='processing' AND lease_until<?",(now.isoformat(timespec='seconds'),))
            task=db.execute("SELECT * FROM tasks WHERE status='pending' AND deleted=0 ORDER BY task_id LIMIT 1").fetchone()
            if not task:return False
            attempt=task['attempt']+1
            db.execute("UPDATE tasks SET status='processing',attempt=?,lease_until=?,error_msg=NULL WHERE task_id=?",(attempt,(now+timedelta(minutes=10)).isoformat(timespec='seconds'),task['task_id']))
            log(db,task['user_id'],'processing','task',task['task_id'],{'attempt':attempt})
        try:
            result=extract(task,app.config)
            with db:
                changed=db.execute("UPDATE tasks SET status='success',result_json=?,finished_time=CURRENT_TIMESTAMP,lease_until=NULL WHERE task_id=? AND status='processing' AND attempt=? AND deleted=0",(dump(result),task['task_id'],attempt)).rowcount
                if changed:log(db,task['user_id'],'extracted','task',task['task_id'],{'components':len(result['components'])})
        except Exception as exc:
            message=exc.message if isinstance(exc,APIError) else f'Extraction failed ({type(exc).__name__}); verify source format or contact administrator'
            if not isinstance(exc,APIError):app.logger.exception('Task %s extraction failed',task['task_id'])
            with db:
                changed=db.execute("UPDATE tasks SET status='failed',error_msg=?,finished_time=CURRENT_TIMESTAMP,lease_until=NULL WHERE task_id=? AND status='processing' AND attempt=? AND deleted=0",(message,task['task_id'],attempt)).rowcount
                if changed:log(db,task['user_id'],'extraction_failed','task',task['task_id'],{'error':message})
        return True
    finally:db.close()


def run_worker(app,stop=None):
    stop=stop or threading.Event()
    while not stop.is_set():
        try:worked=process_one(app)
        except Exception:
            app.logger.exception('Queue worker iteration failed'); worked=False
        if not worked:stop.wait(0.5)


def start_worker(app):
    stop=threading.Event()
    thread=threading.Thread(target=run_worker,args=(app,stop),daemon=True,name='extraction-worker')
    thread.start()
    return stop,thread
