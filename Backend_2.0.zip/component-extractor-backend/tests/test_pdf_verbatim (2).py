import io
import pytest
import pymupdf
from backend.pdf_specs import extract_pdf,table_excerpts,normalize_specifications
from backend.worker import process_one
from backend.common import APIError
from conftest import headers


def make_pdf(path,pages=1):
    d=pymupdf.open()
    for i in range(pages):
        p=d.new_page()
        p.insert_text((40,50),'AD8675 - Analog Devices')
        p.insert_text((40,80),'Supply voltage: 4~6 V')
        p.insert_text((40,110),'Input voltage noise: 3.2 nV/Hz')
        p.insert_text((40,140),'Quiescent current: 45 uA typical, 60 uA maximum')
    d.save(path);d.close()


def test_verbatim_range_long_pdf(tmp_path):
    p=tmp_path/'long.pdf';make_pdf(p,101)
    d=extract_pdf(p)
    assert d['coverage']['total_pages']==101
    assert d['coverage']['all_pages_scanned']
    assert any(s['value_text']=='Supply voltage: 4~6 V' for s in d['specifications'])
    assert any('3.2 nV/Hz' in s['value_text'] for s in d['specifications'])
    assert not d['parameters']


def test_table_preserves_columns_and_duplicates():
    lines=[('Parameter',[0,0,60,10]),('Min',[100,0,110,10]),('Typ',[150,0,160,10]),('Max',[200,0,210,10]),('Unit',[250,0,270,10]),('Supply voltage',[0,20,90,30]),('4',[100,20,110,30]),('5',[150,20,160,30]),('6',[200,20,210,30]),('V',[250,20,270,30])]
    rows=table_excerpts(lines,2)
    assert len(rows)==1
    assert rows[0]['value_text']=='Supply voltage | 4 | 5 | 6 | V'
    assert 'Min | Typ | Max' in rows[0]['source']['context']
    assert len(normalize_specifications(rows+rows))==2


def test_empty_scan_not_success(tmp_path):
    p=tmp_path/'blank.pdf';d=pymupdf.open();d.new_page();d.save(p);d.close()
    with pytest.raises(APIError):extract_pdf(p)


def test_verbatim_upload_audit_publish_search(app,client,tokens,tmp_path):
    app.config['PDF_EXTRACTION_MODE']='verbatim'
    p=tmp_path/'actual.pdf';make_pdf(p)
    response=client.post('/api/tasks/upload',data={'file':(io.BytesIO(p.read_bytes()),'actual.pdf')},headers=headers(tokens))
    assert response.status_code==202
    tid=response.json['data']['task_id'];assert process_one(app)
    task=client.get(f'/api/tasks/{tid}',headers=headers(tokens)).json['data']
    assert task['status']=='success',task
    assert task['result']['method']=='pdf_verbatim'
    image=client.get(f'/api/tasks/{tid}/source/page/1',headers=headers(tokens))
    assert image.status_code==200 and image.data.startswith(b'\x89PNG')
    assert client.get(f'/api/tasks/{tid}/source/page/2',headers=headers(tokens)).status_code==404
    assert client.get(f'/api/tasks/{tid}/source/page/1',headers=headers(tokens,'bob')).status_code==403
    assert client.get(f'/api/tasks/{tid}/source/page/1').status_code==401
    assert client.get('/api/components',headers=headers(tokens)).json['data']['total']==0
    assert client.post(f'/api/audit/tasks/{tid}',json={'action':'approve'},headers=headers(tokens,'auditor')).status_code==400
    result=client.post(f'/api/audit/tasks/{tid}',json={'action':'approve','confirm_specifications':True},headers=headers(tokens,'auditor'))
    assert result.status_code==200,result.json
    cid=result.json['data']['component_ids'][0]
    data=client.get(f'/api/components/{cid}',headers=headers(tokens)).json['data']
    assert data['specifications'][0]['review_status']=='approved'
    assert any('4~6 V' in s['value_text'] for s in data['specifications'])
    assert client.get('/api/components?keyword=4~6',headers=headers(tokens)).json['data']['total']==1
    assert client.get(f'/api/components/{cid}',headers=headers(tokens,'bob')).status_code==403
    exported=client.get('/api/export/components?format=json',headers=headers(tokens))
    assert '4~6 V' in exported.data.decode()
    csv=client.get('/api/export/components?format=csv',headers=headers(tokens))
    assert '4~6 V' in csv.data.decode('utf-8-sig')
    assert 'source_page' in csv.data.decode('utf-8-sig')
    assert client.get(f'/api/components?component_id={cid}',headers=headers(tokens)).json['data']['total']==1
    assert client.get('/api/components?component_id=999999',headers=headers(tokens)).json['data']['total']==0
    corrected=data.copy();corrected['specifications'][0]['value_text']='Supply voltage: 4~5 V'
    edit=client.put(f'/api/components/{cid}',json=corrected,headers=headers(tokens))
    assert edit.status_code==202,edit.json
    tid2=edit.json['data']['task']['task_id'];process_one(app)
    approved=client.post(f'/api/audit/tasks/{tid2}',json={'action':'approve','confirm_specifications':True},headers=headers(tokens,'auditor'))
    assert approved.status_code==200,approved.json
    final=client.get(f'/api/components/{cid}',headers=headers(tokens)).json['data']
    assert len(final['specifications'])==len(data['specifications'])
    assert final['specifications'][0]['value_text']=='Supply voltage: 4~5 V'
    assert final['specifications'][0]['source']['task_id']==tid
