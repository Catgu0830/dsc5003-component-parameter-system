import io
import json
import sqlite3
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import Mock
import pytest
from openpyxl import Workbook,load_workbook
from backend.db import connect
from backend.worker import process_one
from backend.normalization import normalize_parameter,numeric
from backend.common import APIError
from backend.sources import validate_url
from conftest import headers,component,draft,publish


def test_auth_and_revocation(client,tokens):
    assert client.get('/api/components').status_code==401
    assert client.get('/api/auth/me',headers=headers(tokens)).json['data']['role']=='user'
    assert client.post('/api/auth/logout',headers=headers(tokens)).status_code==200
    assert client.get('/api/auth/me',headers=headers(tokens)).status_code==401


def test_register_no_escalation(client):
    assert client.post('/api/auth/register',json={'username':'new','password':'LongPass123','role':'admin'}).status_code==403
    assert client.post('/api/auth/register',json={'username':'new','password':'LongPass123'}).status_code==201
    assert client.post('/api/auth/register',json={'username':'NEW','password':'LongPass123'}).status_code==409
    assert client.post('/api/auth/register',json=[]).status_code==400


def test_hashing_and_foreign_keys(app,client,tokens):
    with connect(app.config['DATABASE']) as db:
        assert db.execute('SELECT password_hash FROM users LIMIT 1').fetchone()[0]!='TestPass123!'
        assert db.execute('SELECT token_hash FROM tokens LIMIT 1').fetchone()[0] not in tokens.values()
        with pytest.raises(sqlite3.IntegrityError):db.execute('INSERT INTO components(model,category,manufacturer_id,owner_id) VALUES(?,?,?,?)',('x','ic',999,999))


def test_review_gate_and_provenance(app,client,tokens):
    task=draft(client,tokens)
    assert client.get('/api/components',headers=headers(tokens)).json['data']['total']==0
    assert process_one(app)
    assert client.get('/api/components',headers=headers(tokens)).json['data']['total']==0
    detail=client.get(f'/api/tasks/{task}',headers=headers(tokens)).json['data']
    assert detail['status']=='success' and detail['review_status']=='pending'
    assert detail['result']['components'][0]['parameters'][0]['value']==3.3
    assert client.post(f'/api/audit/tasks/{task}',json={'action':'approve'},headers=headers(tokens)).status_code==403
    res=client.post(f'/api/audit/tasks/{task}',json={'action':'approve'},headers=headers(tokens,'auditor'))
    assert res.status_code==200
    cid=res.json['data']['component_ids'][0]
    p=client.get(f'/api/components/{cid}/parameters',headers=headers(tokens)).json['data'][0]
    assert p['source']['task_id']==task
    assert client.post(f'/api/audit/tasks/{task}',json={'action':'approve'},headers=headers(tokens,'auditor')).status_code==409


def test_ownership_every_surface(app,client,tokens):
    task,cid=publish(app,client,tokens)
    for path in (f'/api/components/{cid}',f'/api/components/{cid}/parameters',f'/api/tasks/{task}',f'/api/tasks/{task}/source'):
        assert client.get(path,headers=headers(tokens,'bob')).status_code==403
    assert client.get('/api/components',headers=headers(tokens,'bob')).json['data']['total']==0
    assert client.get('/api/tasks',headers=headers(tokens,'bob')).json['data']['total']==0
    assert client.put(f'/api/components/{cid}',json=component(),headers=headers(tokens,'bob')).status_code==403
    assert client.get('/api/logs',headers=headers(tokens)).status_code==403
    assert client.delete(f'/api/components/{cid}',json={'confirm':True},headers=headers(tokens)).status_code==403


def test_reject_and_atomic_batch(app,client,tokens):
    task,cid=publish(app,client,tokens)
    batch=client.post('/api/tasks',json={'components':[component('NEW'),component()]},headers=headers(tokens)).json['data']['task_id']
    process_one(app)
    assert client.post(f'/api/audit/tasks/{batch}',json={'action':'approve'},headers=headers(tokens,'auditor')).status_code==409
    assert client.get('/api/components',headers=headers(tokens)).json['data']['total']==1
    assert client.post(f'/api/audit/tasks/{batch}',json={'action':'reject'},headers=headers(tokens,'auditor')).status_code==400
    assert client.post(f'/api/audit/tasks/{batch}',json={'action':'reject','comment':'duplicate'},headers=headers(tokens,'auditor')).status_code==200
    assert client.get('/api/audit/logs',headers=headers(tokens,'auditor')).json['data']['total']==2


def test_review_correction(app,client,tokens):
    task=draft(client,tokens);process_one(app)
    corrected=component(voltage='5V')
    response=client.post(f'/api/audit/tasks/{task}',json={'action':'approve','components':[corrected],'comment':'checked source'},headers=headers(tokens,'auditor'))
    cid=response.json['data']['component_ids'][0]
    ps=client.get(f'/api/components/{cid}/parameters',headers=headers(tokens)).json['data']
    assert next(p['value'] for p in ps if p['name']=='voltage')==5


def test_update_review_and_stale_revision(app,client,tokens):
    _,cid=publish(app,client,tokens)
    first=client.put(f'/api/components/{cid}',json={'parameters':[{'name':'voltage','value':'5V'}]},headers=headers(tokens)).json['data']['task']['task_id']
    second=client.put(f'/api/components/{cid}',json={'parameters':[{'name':'voltage','value':'9V'}]},headers=headers(tokens)).json['data']['task']['task_id']
    process_one(app);process_one(app)
    assert client.get(f'/api/components/{cid}',headers=headers(tokens)).json['data']['revision']==1
    assert client.post(f'/api/audit/tasks/{first}',json={'action':'approve'},headers=headers(tokens,'auditor')).status_code==200
    assert client.post(f'/api/audit/tasks/{second}',json={'action':'approve'},headers=headers(tokens,'auditor')).status_code==409


def test_combined_filters_and_sql_injection(app,client,tokens):
    publish(app,client,tokens,component('A','3.3V'));publish(app,client,tokens,component('B','5V'))
    filters=json.dumps([{'name':'电压','min':'3300mV','max':'4V'},{'name':'resistance','min':'9kΩ','max':'11kΩ'}])
    response=client.get('/api/components',query_string={'filters':filters,'package':'0603'},headers=headers(tokens))
    assert response.status_code==200 and response.json['data']['total']==1
    assert response.json['data']['items'][0]['model']=='A'
    assert client.get('/api/components',query_string={'keyword':"' OR 1=1 --"},headers=headers(tokens)).json['data']['total']==0
    assert client.get('/api/components?sort=model;DROP%20TABLE%20users',headers=headers(tokens)).status_code==400
    assert client.get('/api/components?filters=oops',headers=headers(tokens)).status_code==400
    assert client.get('/api/components?page_size=1000',headers=headers(tokens)).status_code==400


def test_comparison_and_all_exports(app,client,tokens):
    _,a=publish(app,client,tokens,component('A'))
    bdata=component('B','5V');bdata['parameters']=bdata['parameters'][:1]
    _,b=publish(app,client,tokens,bdata)
    result=client.get(f'/api/components/compare?ids={a},{b}',headers=headers(tokens)).json['data']
    assert next(r for r in result['rows'] if r['name']=='voltage')['different']
    assert next(r for r in result['rows'] if r['name']=='resistance')['missing_component_ids']==[b]
    for kind in ('json','csv','xlsx'):
        response=client.get('/api/export/components?format='+kind,headers=headers(tokens));assert response.status_code==200
        if kind=='xlsx':assert load_workbook(io.BytesIO(response.data)).active.max_row==3
    assert client.get(f'/api/export/compare?ids={a},{b}&format=json',headers=headers(tokens)).status_code==200
    assert client.get('/api/export/components?format=pdf',headers=headers(tokens)).status_code==400


def test_csv_excel_import(app,client,tokens):
    data='model,manufacturer,category,voltage,capacitance\nCAP,ACME,capacitor,25V,100nF\n'
    response=client.post('/api/tasks/upload',data={'file':(io.BytesIO(data.encode()),'example.csv')},headers=headers(tokens))
    tid=response.json['data']['task_id'];process_one(app)
    detail=client.get(f'/api/tasks/{tid}',headers=headers(tokens)).json['data']
    assert detail['status']=='success'
    cap=next(p for p in detail['result']['components'][0]['parameters'] if p['name']=='capacitance')
    assert cap['value']==pytest.approx(1e-7) and cap['source']['row']==2
    assert not str(app.config['UPLOAD_DIR']) in json.dumps(detail)
    book=Workbook();book.active.append(['model','manufacturer','category','current']);book.active.append(['IC','ACME','ic','200mA']);buf=io.BytesIO();book.save(buf);buf.seek(0)
    response=client.post('/api/tasks/upload',data={'file':(buf,'test.xlsx')},headers=headers(tokens));tid=response.json['data']['task_id'];process_one(app)
    assert client.get(f'/api/tasks/{tid}',headers=headers(tokens)).json['data']['status']=='success'


@pytest.mark.parametrize('filename,content',[('bad.exe',b'x'),('bad.pdf',b'not a pdf'),('bad.xlsx',b'PKxxx'),('bad.csv',b'\xff\x00'),('empty.csv',b'')])
def test_upload_validation(client,tokens,filename,content):
    assert client.post('/api/tasks/upload',data={'file':(io.BytesIO(content),filename)},headers=headers(tokens)).status_code==400


def test_size_limit(client,tokens):
    response=client.post('/api/tasks/upload',data={'file':(io.BytesIO(b'a'*1100000),'large.csv')},headers=headers(tokens))
    assert response.status_code==413 and response.json['code']==413


def test_failed_retry_limit(app,client,tokens):
    response=client.post('/api/tasks/upload',data={'file':(io.BytesIO(b'wrong,columns\nx,y\n'),'bad.csv')},headers=headers(tokens))
    tid=response.json['data']['task_id'];process_one(app)
    assert client.get(f'/api/tasks/{tid}',headers=headers(tokens)).json['data']['status']=='failed'
    for _ in range(2):
        assert client.post(f'/api/tasks/{tid}/retry',headers=headers(tokens)).status_code==202
        process_one(app)
    assert client.post(f'/api/tasks/{tid}/retry',headers=headers(tokens)).status_code==409


def test_pause_resume_cancel_and_delete(app,client,tokens):
    tid=draft(client,tokens)
    assert client.post(f'/api/tasks/{tid}/pause',headers=headers(tokens)).status_code==200
    assert not process_one(app)
    assert client.post(f'/api/tasks/{tid}/resume',headers=headers(tokens)).status_code==200
    assert client.post(f'/api/tasks/{tid}/terminate',headers=headers(tokens)).status_code==200
    assert not process_one(app)
    assert client.delete(f'/api/tasks/{tid}',json={},headers=headers(tokens,'admin')).status_code==400
    assert client.delete(f'/api/tasks/{tid}',json={'confirm':True},headers=headers(tokens,'admin')).status_code==200
    assert client.get(f'/api/tasks/{tid}',headers=headers(tokens)).status_code==404


def test_worker_concurrent_claim(app,client,tokens):
    tid=draft(client,tokens)
    with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(lambda _:process_one(app),range(2)))
    assert sum(results)==1
    assert client.get(f'/api/tasks/{tid}',headers=headers(tokens)).json['data']['attempt']==1


@pytest.mark.parametrize('name,value,expected,unit',[('voltage','3300mV',3.3,'V'),('current','200mA',0.2,'A'),('resistance','10kΩ',10000,'Ω'),('capacitance','100nF',1e-7,'F'),('frequency','16MHz',16000000,'Hz'),('capacitance','2.2uF',2.2e-6,'F'),('tolerance','5%',5,'%')])
def test_units(name,value,expected,unit):
    actual,base=numeric(value,None,name)
    assert actual==pytest.approx(expected) and base==unit


@pytest.mark.parametrize('value,unit',[('NaN','V'),('inf','V'),('3-5V',None),('3A',None),(3,None),(True,'V'),('1e999','V')])
def test_invalid_numeric(value,unit):
    with pytest.raises(APIError):numeric(value,unit,'voltage')


def test_missing_and_alias():
    p,w=normalize_parameter({'name':'voltage','value':None})
    assert p is None and w
    p,w=normalize_parameter({'name':'工作电压','value':'3.3'},allow_missing_unit=True)
    assert p['unit'] is None and w


@pytest.mark.parametrize('url',['http://127.0.0.1/','http://[::1]/','http://169.254.169.254/','file:///etc/passwd','http://user:pw@example.com','http://example.com:5000','http://10.0.0.1'])
def test_ssrf(url):
    with pytest.raises(APIError):validate_url(url)


def test_dns_rebind_prevention(monkeypatch):
    import socket
    monkeypatch.setattr(socket,'getaddrinfo',lambda *a,**k:[(2,1,6,'',('127.0.0.1',80)),(2,1,6,'',('8.8.8.8',80))])
    with pytest.raises(APIError):validate_url('http://example.com')


def test_llm_valid_and_hallucination(monkeypatch):
    from backend.extraction import parse_llm
    raw=component();raw['parameters']=[{'name':'voltage','value':'3.3V','source':{'snippet':'Voltage: 3.3V'}}]
    response=Mock(status_code=200,content=b'{}')
    response.json.return_value={'choices':[{'message':{'content':json.dumps({'components':[raw]})},'finish_reason':'stop'}]}
    monkeypatch.setattr('backend.extraction.requests.post',lambda *a,**k:response)
    config={'LLM_API_KEY':'fake-test','LLM_MODEL':'test','LLM_API_BASE':'https://test.invalid/v1','LLM_TIMEOUT':1}
    assert parse_llm('Voltage: 3.3V',config)[0]['model']=='TEST-R'
    with pytest.raises(APIError):parse_llm('Voltage: 5V',config)
    response.status_code=429
    with pytest.raises(APIError):parse_llm('Voltage: 3.3V',config)


def test_cors_admin_and_backup(app,client,tokens,tmp_path):
    preflight=client.options('/api/tasks',headers={'Origin':'http://localhost:5500'})
    assert preflight.headers['Access-Control-Allow-Origin']=='http://localhost:5500'
    assert 'Access-Control-Allow-Origin' not in client.get('/api/health',headers={'Origin':'https://evil.invalid'}).headers
    assert client.put('/api/users/1',json={'disabled':True},headers=headers(tokens,'admin')).status_code==409
    response=client.put('/api/users/3',json={'disabled':True},headers=headers(tokens,'admin'));assert response.status_code==200
    assert client.get('/api/auth/me',headers=headers(tokens)).status_code==401
    backup=tmp_path/'backup.db'
    result=app.test_cli_runner().invoke(args=['backup-db',str(backup)])
    assert result.exit_code==0
    with connect(backup) as db:assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'


def test_manufacturer_alias_and_formula_escape(app,client,tokens):
    response=client.post('/api/manufacturers',json={'name':'Canonical','aliases':['Alias']},headers=headers(tokens,'auditor'))
    assert response.status_code==200
    data=component('=SUM(1,2)');data['manufacturer']='Alias'
    publish(app,client,tokens,data)
    result=client.get('/api/components?manufacturer=Alias',headers=headers(tokens)).json['data']
    assert result['total']==1 and result['items'][0]['manufacturer']=='Canonical'
    csv=client.get('/api/export/components?format=csv',headers=headers(tokens)).data.decode('utf-8-sig')
    assert "'=SUM" in csv
