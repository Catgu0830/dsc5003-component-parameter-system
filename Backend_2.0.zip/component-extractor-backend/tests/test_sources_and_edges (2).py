import io,json
from unittest.mock import Mock
import pytest
from backend.common import APIError
from backend.worker import process_one
from backend.sources import fetch_web
from backend.db import connect
from conftest import headers,component,draft,publish


def test_pdf_real_parser(app,client,tokens,tmp_path):
    from scripts.seed_demo import sample_pdf
    pdf=tmp_path/'test.pdf';sample_pdf(pdf)
    response=client.post('/api/tasks/upload',data={'file':(io.BytesIO(pdf.read_bytes()),'datasheet.pdf')},headers=headers(tokens))
    tid=response.json['data']['task_id'];process_one(app)
    result=client.get(f'/api/tasks/{tid}',headers=headers(tokens)).json['data']
    assert result['status']=='success',result
    c=result['result']['components'][0]
    assert c['model']=='DEMO-LDO33'
    assert c['parameters'][0]['source']['page']==1
    approved=client.post(f'/api/audit/tasks/{tid}',json={'action':'approve'},headers=headers(tokens,'auditor'))
    assert approved.status_code==200,approved.json
    assert client.get(f'/api/tasks/{tid}/source',headers=headers(tokens)).data.startswith(b'%PDF-')


def test_web_robots_and_html(monkeypatch):
    monkeypatch.setattr('backend.sources.validate_url',lambda *a: (__import__('urllib.parse',fromlist=['urlsplit']).urlsplit(a[0]),'8.8.8.8'))
    def fetch(url,*a,**kw):
        if url.endswith('/robots.txt'):return 200,b'User-agent: *\nDisallow: /private','text/plain',url
        return 200,b'<html><script>secret</script><h1>Model: R1</h1><p>Voltage: 5V</p></html>','text/html',url
    monkeypatch.setattr('backend.sources.public_get',fetch)
    content,final=fetch_web('https://example.test/data')
    assert 'Voltage: 5V' in content and 'secret' not in content
    with pytest.raises(APIError,match='disallows'):fetch_web('https://example.test/private')


def test_web_redirect_rechecks_robots(monkeypatch):
    from urllib.parse import urlsplit
    monkeypatch.setattr('backend.sources.validate_url',lambda u,*a:(urlsplit(u),'8.8.8.8'))
    seen=[]
    def fetch(url,*a,**kw):
        seen.append(url)
        if url=='https://one.test/robots.txt':return 404,b'','',url
        if url=='https://two.test/robots.txt':return 200,b'User-agent: *\nDisallow: /','text/plain',url
        raise APIError('Too many redirects or missing redirect target')
    monkeypatch.setattr('backend.sources.public_get',fetch)
    monkeypatch.setattr('backend.sources.redirect_target',lambda *a:'https://two.test/data')
    with pytest.raises(APIError,match='disallows'):fetch_web('https://one.test/data')
    assert 'https://two.test/robots.txt' in seen


def test_missing_unit_draft_not_approvable(app,client,tokens):
    response=client.post('/api/tasks/upload',data={'file':(io.BytesIO(b'model,manufacturer,category,voltage\nIC1,ACME,ic,3.3\n'),'missing.csv')},headers=headers(tokens))
    tid=response.json['data']['task_id'];process_one(app)
    assert client.get(f'/api/tasks/{tid}',headers=headers(tokens)).json['data']['status']=='success'
    assert client.post(f'/api/audit/tasks/{tid}',json={'action':'approve'},headers=headers(tokens,'auditor')).status_code==400
    assert client.get('/api/components',headers=headers(tokens)).json['data']['total']==0


def test_duplicate_overwrite_confirmation_and_revision(app,client,tokens):
    _,cid=publish(app,client,tokens)
    tid=draft(client,tokens,component(voltage='5V'));process_one(app)
    endpoint=f'/api/audit/tasks/{tid}';auth=headers(tokens,'auditor')
    assert client.post(endpoint,json={'action':'approve'},headers=auth).status_code==409
    assert client.post(endpoint,json={'action':'approve','confirm_overwrite':True},headers=auth).status_code==409
    assert client.post(endpoint,json={'action':'approve','confirm_overwrite':True,'expected_revisions':{str(cid):1}},headers=auth).status_code==200
    assert client.get(f'/api/components/{cid}',headers=headers(tokens)).json['data']['revision']==2


def test_deleted_update_target_not_resurrected(app,client,tokens):
    _,cid=publish(app,client,tokens)
    tid=client.put(f'/api/components/{cid}',json={'model':'EDITED'},headers=headers(tokens)).json['data']['task']['task_id']
    process_one(app)
    assert client.delete(f'/api/components/{cid}',json={'confirm':True},headers=headers(tokens,'admin')).status_code==200
    assert client.post(f'/api/audit/tasks/{tid}',json={'action':'approve'},headers=headers(tokens,'auditor')).status_code==409


def test_crashed_worker_lease_recovery(app,client,tokens):
    tid=draft(client,tokens)
    db=connect(app.config['DATABASE'])
    with db:db.execute("UPDATE tasks SET status='processing',lease_until='2000-01-01T00:00:00+00:00' WHERE task_id=?",(tid,))
    db.close()
    assert not process_one(app)
    result=client.get(f'/api/tasks/{tid}',headers=headers(tokens)).json['data']
    assert result['status']=='failed' and 'lease expired' in result['error_msg']


def test_export_reimport_units(app,client,tokens):
    publish(app,client,tokens)
    csv=client.get('/api/export/components?format=csv',headers=headers(tokens)).data
    response=client.post('/api/tasks/upload',data={'file':(io.BytesIO(csv),'roundtrip.csv')},headers=headers(tokens))
    tid=response.json['data']['task_id'];process_one(app)
    result=client.get(f'/api/tasks/{tid}',headers=headers(tokens)).json['data']
    assert result['status']=='success',result
    assert next(p for p in result['result']['components'][0]['parameters'] if p['name']=='voltage')['unit']=='V'


def test_batch_history(app,client,tokens):
    tid=client.post('/api/tasks',json={'components':[component('ONE'),component('TWO')]},headers=headers(tokens)).json['data']['task_id'];process_one(app)
    result=client.post(f'/api/audit/tasks/{tid}',json={'action':'approve'},headers=headers(tokens,'auditor'))
    for cid in result.json['data']['component_ids']:
        assert client.get(f'/api/components/{cid}',headers=headers(tokens)).json['data']['history'][0]['task_id']==tid


def test_parameter_draft_and_user_admin_management(app,client,tokens):
    _,cid=publish(app,client,tokens)
    res=client.post(f'/api/components/{cid}/parameters',json={'name':'capacitance','value':'1uF'},headers=headers(tokens))
    assert res.status_code==202
    assert 'capacitance' not in {p['name'] for p in client.get(f'/api/components/{cid}/parameters',headers=headers(tokens)).json['data']}
    assert client.post('/api/users',json={'username':'newauditor','password':'NewPass123!','role':'auditor'},headers=headers(tokens,'admin')).status_code==201
    assert client.get('/api/users',headers=headers(tokens,'admin')).json['data']['total']==5


def test_llm_mode_missing_key_fails_cleanly(app,client,tokens,tmp_path):
    from scripts.seed_demo import sample_pdf
    app.config['EXTRACTION_MODE']='llm'
    pdf=tmp_path/'doc.pdf';sample_pdf(pdf)
    tid=client.post('/api/tasks/upload',data={'file':(io.BytesIO(pdf.read_bytes()),'test.pdf')},headers=headers(tokens)).json['data']['task_id']
    process_one(app)
    result=client.get(f'/api/tasks/{tid}',headers=headers(tokens)).json['data']
    assert result['status']=='failed' and 'LLM_API_KEY' in result['error_msg']


@pytest.mark.parametrize('source',[[],{'page':0},{'snippet':42}])
def test_invalid_provenance_is_400(client,tokens,source):
    data=component();data['parameters'][0]['source']=source
    assert client.post('/api/tasks',json={'component':data},headers=headers(tokens)).status_code==400


def test_openapi_matches_routes(app):
    import re
    from pathlib import Path
    spec=json.loads((Path(__file__).resolve().parents[1]/'docs/openapi.json').read_text(encoding='utf-8'))
    ids=[]
    for rule in app.url_map.iter_rules():
        if rule.endpoint=='static':continue
        path=re.sub(r'<(?:int:)?(\w+)>',r'{\1}',rule.rule)
        paths=[path.replace('{action}',a) for a in ('pause','resume','terminate')] if '{action}' in path else [path]
        for p in paths:
            for method in rule.methods-{'HEAD','OPTIONS'}:
                operation=spec['paths'][p][method.lower()]
                ids.append(operation['operationId'])
    assert len(ids)==len(set(ids))


def test_database_first_search_and_missing_parameter(app,client,tokens):
    publish(app,client,tokens)
    total=client.get('/api/tasks',headers=headers(tokens)).json['data']['total']
    response=client.post('/api/search',json={'query':{'keyword':'TEST-R','required_parameters':['voltage']},'source':{'component':component()}},headers=headers(tokens))
    assert response.status_code==200 and response.json['data']['mode']=='database'
    assert client.get('/api/tasks',headers=headers(tokens)).json['data']['total']==total
    response=client.post('/api/search',json={'query':{'keyword':'TEST-R','required_parameters':['capacitance']},'source':{'component':component('NEW')}},headers=headers(tokens))
    assert response.status_code==202 and response.json['data']['mode']=='extraction'
    assert client.get('/api/tasks',headers=headers(tokens)).json['data']['total']==total+1


def test_unknown_dimension_cannot_be_silently_range_compared(client,tokens):
    response=client.get('/api/components',query_string={'filters':json.dumps([{'name':'custom_distance','min':'3km'}])},headers=headers(tokens))
    assert response.status_code==400
