// File-level review: one queue row and one decision per uploaded file.
document.addEventListener('DOMContentLoaded', async () => {
 const $=id=>document.getElementById(id);
 const node=(tag,text)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;return n;};
 let page=1,totalPages=1,current=null,records=[],definitions=[],specPage=1,busy=false,previewUrl=null;
 const message=(id,text,error=false)=>{$(id).textContent=text;$(id).className='form-message '+(error?'error':'success');};
 const run=fn=>async()=>{try{await fn();}catch(e){message(current?'detailMessage':'listMessage',e.message,true);}};
 const cell=(tr,value)=>{const td=node('td');if(value instanceof Node)td.append(value);else td.textContent=value??'-';tr.append(td);return td;};
 const button=(label,fn)=>{const b=node('button',label);b.className='secondary-button';b.type='button';b.onclick=run(fn);return b;};
 const request=async(path,method='GET',body)=> (await apiRequest(path,{method,body})).data;
 const modified=()=>records.some(p=>p.dirty||(p.review_status==='pending'&&!p.include)) || (current && ['Model','Manufacturer','Category','Package'].some(k=>$('identity'+k).value!==(current.result.components[0][k.toLowerCase()]||'')));
 const leave=()=>!current||!modified()||window.confirm('Discard unsaved changes to this file?');
 if(!getToken()){location.href='../login.html';return;}
 async function queue(){
  const data=await request(`/api/audit/tasks?page=${page}&page_size=20`);
  totalPages=Math.max(1,Math.ceil(data.total/20));$('reviewCount').textContent=`${data.total} pending file(s)`;
  $('pendingBody').replaceChildren();
  for(const t of data.items){const tr=node('tr');[t.task_id,t.original_filename||t.source_location||'Manual entry',t.extracted_model,t.source_type,t.param_count,formatHongKongTime(t.created_time)].forEach(v=>cell(tr,v));cell(tr,button('Review File',()=>open(t.task_id)));$('pendingBody').append(tr);}
  if(!data.items.length){const tr=node('tr');cell(tr,'No files waiting for review.').colSpan=7;$('pendingBody').append(tr);}
  $('pageInfo').textContent=`Page ${page} / ${totalPages}`;$('prevPage').disabled=page<=1;$('nextPage').disabled=page>=totalPages;
 }
 async function history(){
  const data=await request('/api/audit/files/history?page_size=20');$('auditLogsBody').replaceChildren();
  for(const h of data.items){const tr=node('tr');[formatHongKongTime(h.created_time),h.target_id,h.filename,h.username,h.action==='approve_file'?'Approved':'Rejected',h.detail.comment||''].forEach(v=>cell(tr,v));$('auditLogsBody').append(tr);}
  if(!data.items.length){const tr=node('tr');cell(tr,'No file decisions yet.').colSpan=6;$('auditLogsBody').append(tr);}
 }
 async function open(id){
  if(!leave())return;
  current=await request('/api/audit/tasks/'+id);
  const c=current.result.components[0];
  records=c.parameters.map(p=>({...p,include:p.review_status!=='rejected',dirty:false})).sort((a,b)=>(a.source?.page||0)-(b.source?.page||0)||a.extraction_param_id-b.extraction_param_id);
  $('reviewPanel').hidden=false;$('reviewTaskId').textContent=current.original_filename||`#${id}`;
  $('detailMessage').textContent='';$('fileComment').value='';$('sourcePreview').hidden=true;
  $('taskInfo').replaceChildren();
  for(const [label,value] of [['File',current.original_filename||'Manual entry'],['Model',c.model],['Specifications',records.length],['Extraction',current.status]]){const d=node('div');d.className='task-info-item';d.append(node('strong',label),node('span',value));$('taskInfo').append(d);}
  $('identityModel').value=c.model||'';$('identityManufacturer').value=c.manufacturer||'';$('identityCategory').value=c.category||'';$('identityPackage').value=c.package||'';
  $('specPage').replaceChildren(new Option('All pages',''));[...new Set(records.map(p=>p.source?.page).filter(Boolean))].sort((a,b)=>a-b).forEach(p=>$('specPage').add(new Option('Page '+p,p)));
  $('specSearch').value='';specPage=1;render();$('reviewPanel').scrollIntoView({behavior:'smooth'});
 }
 function filtered(){const q=$('specSearch').value.toLowerCase(),p=$('specPage').value;return records.filter(r=>(!p||String(r.source?.page)===p)&&(r.raw_name+' '+r.raw_value).toLowerCase().includes(q));}
 function summary(){const included=records.filter(p=>p.include).length,original=records.filter(p=>p.include&&!p.parameter_id).length;
  $('decisionSummary').textContent=`Approve this file: ${included} included specifications, ${records.length-included} excluded. ${original} unclassified specifications will be kept as original text. No individual approval is required.`;
 }
 async function source(p){
  const r=await fetch(API_BASE_URL+`/api/tasks/${current.task_id}/source/page/${p}`,{headers:{Authorization:'Bearer '+getToken()}});if(!r.ok)throw Error('Unable to open source page');
  if(previewUrl)URL.revokeObjectURL(previewUrl);previewUrl=URL.createObjectURL(await r.blob());$('sourceImage').src=previewUrl;$('sourcePreview').hidden=false;$('sourcePreview').scrollIntoView({behavior:'smooth'});
 }
 function render(){
  const list=filtered();$('paramBody').replaceChildren();
  for(const p of list.slice((specPage-1)*20,specPage*20)){
   const tr=node('tr'),locked=p.review_status!=='pending';
   const include=node('input');include.type='checkbox';include.checked=p.include;include.disabled=locked;include.setAttribute('aria-label','Include '+p.raw_name);include.onchange=()=>{p.include=include.checked;summary();};cell(tr,include);cell(tr,p.raw_name);
   const value=node('textarea');value.value=p.raw_value;value.disabled=locked;value.setAttribute('aria-label','Value '+p.raw_name);value.oninput=()=>{p.raw_value=value.value;p.dirty=true;};cell(tr,value);
   const select=node('select');select.add(new Option('Keep original specification',''));for(const d of definitions)select.add(new Option(d.display_name,d.parameter_id));
   if(p.parameter_id&&!definitions.some(d=>d.parameter_id===p.parameter_id))select.add(new Option(p.name,p.parameter_id));
   select.value=p.parameter_id||'';select.disabled=locked;select.setAttribute('aria-label','Classification '+p.raw_name);select.onchange=()=>{p.parameter_id=select.value?Number(select.value):null;p.dirty=true;summary();};cell(tr,select);
   const unit=node('input');unit.value=p.unit||'';unit.disabled=locked;unit.setAttribute('aria-label','Unit '+p.raw_name);unit.oninput=()=>{p.unit=unit.value;p.dirty=true;};cell(tr,unit);
   const evidence=node('details');evidence.append(node('summary',p.source?.page?'Page '+p.source.page:'Manual source'),node('p',p.source?.snippet||p.raw_value));if(p.source?.page)evidence.append(button('View PDF page',()=>source(p.source.page)));cell(tr,evidence);$('paramBody').append(tr);
  }
  $('specSummary').textContent=`${list.length} matching specifications (of ${records.length}). Values are preserved as text, including ranges and conditions.`;
  $('specPageInfo').textContent=`${specPage} / ${Math.max(1,Math.ceil(list.length/20))}`;$('specPrev').disabled=specPage<=1;$('specNext').disabled=specPage*20>=list.length;summary();
 }
 async function decide(action){
  if(busy||!current)return;
  const comment=$('fileComment').value.trim();if(action==='reject'&&!comment)throw Error('Please give a reason for rejecting this file');
  const count=records.filter(p=>p.include).length;
  if(action==='approve'&&!count)throw Error('No included specifications remain. Reject the file instead.');
  if(!window.confirm(action==='approve'?`Approve ${current.original_filename||'this file'} and publish ${count} included specifications?`:`Reject ${current.original_filename||'this file'}? Nothing from this file will be published.`))return;
  const payload={action,comment,expected_revision:current.review_revision};
  if(action==='approve'){
   payload.identity={model:$('identityModel').value,manufacturer:$('identityManufacturer').value,category:$('identityCategory').value,package:$('identityPackage').value};
   payload.edits=records.filter(p=>p.dirty).map(p=>({extraction_param_id:p.extraction_param_id,parameter_id:p.parameter_id,raw_value:p.raw_value,unit:p.unit||null}));
   payload.exclude_ids=records.filter(p=>!p.include&&p.review_status==='pending').map(p=>p.extraction_param_id);
  }
  busy=true;$('approveFile').disabled=true;$('rejectFile').disabled=true;
  try{const result=await request(`/api/audit/tasks/${current.task_id}/review`,'POST',payload);current=null;records=[];$('reviewPanel').hidden=true;page=1;await queue();await history();message('listMessage',action==='approve'?`File approved. Component ${result.component_id} is now available in the library.`:'File rejected. Nothing was published.');}
  finally{busy=false;$('approveFile').disabled=false;$('rejectFile').disabled=false;}
 }
 $('approveFile').onclick=run(()=>decide('approve'));$('rejectFile').onclick=run(()=>decide('reject'));
 $('specSearch').oninput=()=>{specPage=1;render();};$('specPage').onchange=()=>{specPage=1;render();};
 $('specPrev').onclick=()=>{specPage--;render();};$('specNext').onclick=()=>{specPage++;render();};
 $('prevPage').onclick=run(async()=>{page--;await queue();});$('nextPage').onclick=run(async()=>{page++;await queue();});
 $('closeReview').onclick=()=>{if(!leave())return;current=null;records=[];$('reviewPanel').hidden=true;};
 $('backHome').onclick=()=>{if(leave())location.href='dashboard.html';};$('refreshLogs').onclick=run(history);
 $('saveIdentity').hidden=true;
 $('downloadSource').onclick=run(async()=>{const r=await fetch(API_BASE_URL+`/api/tasks/${current.task_id}/source`,{headers:{Authorization:'Bearer '+getToken()}});if(!r.ok)throw Error('Unable to download source');const url=URL.createObjectURL(await r.blob()),a=node('a');a.href=url;a.download=current.original_filename||'source.pdf';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
 try{
  const me=await request('/api/auth/me');if(!['admin','auditor'].includes(me.role)){location.href='dashboard.html';return;}
  const [cats,params]=await Promise.all([request('/api/categories'),request('/api/parameters')]);definitions=params.items.filter(d=>!d.canonical_name.startsWith('source_'));
  $('identityCategory').replaceChildren(new Option('Select category',''));cats.items.forEach(c=>$('identityCategory').add(new Option(getCategoryDisplayName(c.name),c.name)));
  await queue();await history();
  const tid=new URLSearchParams(location.search).get('task');if(tid)await open(Number(tid));
 }catch(e){message('listMessage',e.message,true);}
});
