
// ========================================
// API Request Module
// Backend: Flask + SQLite
// ========================================

const API_BASE_URL = window.COMPONENT_API_BASE_URL ||
    (['5500', '5501'].includes(window.location.port)
        ? window.location.protocol + '//' + window.location.hostname + ':5000'
        : window.location.origin);

// ------------------------------------
// Category Display Labels
// Keep backend category values unchanged.
// Only translate the text shown in dropdowns.
// ------------------------------------

function getCategoryDisplayName(category) {

    const raw = String(category ?? "").trim();
    const normalized = raw.toLowerCase().replace(/[\s_-]+/g, "");

    const labels = {
        // Resistor
        "电阻": "Resistor",
        "电阻器": "Resistor",
        "resistor": "Resistor",
        "resistors": "Resistor",

        // Capacitor
        "电容": "Capacitor",
        "电容器": "Capacitor",
        "capacitor": "Capacitor",
        "capacitors": "Capacitor",

        // Diode
        "二极管": "Diode",
        "diode": "Diode",
        "diodes": "Diode",

        // Transistor
        "三极管": "Transistor",
        "晶体管": "Transistor",
        "transistor": "Transistor",
        "transistors": "Transistor",

        // Integrated circuit
        "芯片": "Integrated Circuit",
        "集成电路": "Integrated Circuit",
        "ic": "Integrated Circuit",
        "integratedcircuit": "Integrated Circuit",
        "integratedcircuits": "Integrated Circuit",

        // Inductor
        "电感": "Inductor",
        "电感器": "Inductor",
        "inductor": "Inductor",
        "inductors": "Inductor",

        // Other
        "其他": "Other",
        "其它": "Other",
        "other": "Other"
    };

    return labels[normalized] || raw;
}

// ------------------------------------
// Authentication Token Management
// ------------------------------------

// Get current authentication token
function getToken() {
    return localStorage.getItem("token");
}

// Save authentication token
function saveToken(token) {
    localStorage.setItem("token", token);
}

// Clear authentication information
function clearAuth() {
    localStorage.removeItem("token");
    localStorage.removeItem("currentUser");
}

// ------------------------------------
// API Error Handling
// ------------------------------------

function getEnglishErrorMessage(result, status) {

    const fallback = `Request failed (HTTP ${status}). Please try again.`;

    if (typeof result === "object" && result !== null) {

        const message = String(result.message || "");

        // Preserve already-English server messages
        if (message && !/[\u4e00-\u9fff]/.test(message)) {
            return message;
        }

        // Use an English fallback for Chinese server messages
        if (message) {
            return fallback;
        }

    }

    if (typeof result === "string" && result.trim()) {

        if (!/[\u4e00-\u9fff]/.test(result)) {
            return result;
        }

    }

    return fallback;
}

// ------------------------------------
// Unified API Request Function
// ------------------------------------

async function apiRequest(path, options = {}) {

    const {
        method = "GET",
        body,
        auth = true,
        headers = {}
    } = options;

    const requestHeaders = { ...headers };

    // Automatically set JSON Content-Type
    if (
        body !== undefined &&
        !(body instanceof FormData)
    ) {
        requestHeaders["Content-Type"] = "application/json";
    }

    // Automatically attach authentication token
    const token = getToken();

    if (auth && token) {
        requestHeaders["Authorization"] = `Bearer ${token}`;
    }

    // Send API request
    const response = await fetch(
        `${API_BASE_URL}${path}`,
        {
            method,
            headers: requestHeaders,
            body: body === undefined
                ? undefined
                : body instanceof FormData
                    ? body
                    : JSON.stringify(body)
        }
    );

    // Parse response
    const contentType =
        response.headers.get("content-type") || "";

    let result;

    if (contentType.includes("application/json")) {

        result = await response.json();

    } else {

        result = await response.text();

    }

    // ------------------------------------
    // HTTP Error Handling
    // ------------------------------------

    if (!response.ok) {

        if (response.status === 401 && auth) {
            clearAuth();
            window.location.href = window.location.pathname.startsWith("/frontend/") ? "/frontend/login.html" : "/login.html";
        }

        console.error(
            "API Error:",
            response.status,
            result
        );

        throw new Error(
            getEnglishErrorMessage(result, response.status)
        );

    }

    // ------------------------------------
    // Application-Level Error Handling
    // ------------------------------------

    if (
        typeof result === "object" &&
        result !== null &&
        result.code !== undefined &&
        result.code !== 0
    ) {

        console.error("API Application Error:", result);

        throw new Error(
            getEnglishErrorMessage(result, response.status)
        );

    }

    // Return successful response
    return result;

}

// SQLite timestamps are UTC even when their string omits a zone.
function parseServerDate(value) {
    if (!value) return new Date(NaN);
    let text = String(value).trim();
    if (/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?$/.test(text)) text = text.replace(' ', 'T') + 'Z';
    return new Date(text);
}



function formatHongKongTime(value) {
    if (!value) return '-';
    const date = parseServerDate(value);
    if (Number.isNaN(date.getTime())) return String(value);
    return new Intl.DateTimeFormat('en-GB', {
        timeZone: 'Asia/Hong_Kong', year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23'
    }).format(date) + ' HKT (UTC+8)';
}
