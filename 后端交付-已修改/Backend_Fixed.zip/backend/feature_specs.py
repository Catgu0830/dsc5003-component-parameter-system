"""Feature evidence collected without the numeric-unit gate used for generic prose."""
import re
RULES = [
 ('core', 'CPU core', r'(Cortex[®\s-]*[AMR]\d+\+?)'),
 ('cpu_frequency', 'Maximum CPU frequency', r'(\d+(?:\.\d+)?\s*MHz)\s+(?:maximum frequency|max\.)'),
 ('core', 'CPU core', r'(?:core|processor|CPU)[ :]+(RISC-V|Xtensa[^,;\n]{0,35})'),
 ('flash', 'Flash capacity', r'((?:up to\s+)?\d+(?:\s+to\s+\d+)?\s*-?[KM](?:bytes?|B))\s+(?:of\s+)?Flash'),
 ('ram', 'SRAM capacity', r'((?:up to\s+)?\d+(?:\s+to\s+\d+)?\s*-?K(?:bytes?|B))\s+(?:of\s+)?(?:SRAM|RAM)\b'),
 ('eeprom', 'EEPROM capacity', r'(\d+\s*-?[KM](?:bytes?|B))\s+(?:of\s+data\s+)?EEPROM'),
 ('supply_range', 'Operating supply range', r'([0-9.]+\s*V?\s+to\s+[0-9.]+\s*V)\s+(?:application supply|power supply)'),
 ('temperature_range', 'Operating temperature range', r'([-+]?\d+\s*(?:°C)?\s+to\s+[-+]?\d+\s*°C)\s+(?:operating\s+)?temperature range'),
 ('adc_resolution', 'ADC resolution', r'(\d+)[ -]bit\s+ADC'),
]

def feature_excerpts(page, page_no):
    # Introductory feature blocks; keep column boundaries and exact source text.
    if page_no > 3: return []
    result=[];seen=set()
    for block in page.get_text('blocks'):
        text=block[4]
        if re.search(r'table of contents|list of tables|revision history',text,re.I):continue
        lines=text.splitlines()
        for i in range(len(lines)):
            excerpt='\n'.join(lines[i:i+3]).strip()
            normalized=re.sub(r'\s+',' ',excerpt.replace('®','').replace('–','-'))
            for key,label,pattern in RULES:
                m=re.search(pattern,normalized,re.I)
                if not m:continue
                # Never infer CPU maximum from oscillator or interface frequencies.
                if key=='cpu_frequency' and re.search(r'oscillator|crystal|SPI|USB|ADC',normalized,re.I):continue
                signature=(key,m.group(1))
                if signature in seen:continue
                seen.add(signature)
                result.append(dict(label=label,value_text=excerpt,unit_text=None,min_text=None,typ_text=None,max_text=None,
                    conditions_text=None,applicability_text='Datasheet family; verify ordering variant',kind='verbatim_excerpt',review_status='pending',
                    source=dict(page=page_no,bbox=list(block[:4]),snippet=excerpt,context=text[:3000])))
    return result
