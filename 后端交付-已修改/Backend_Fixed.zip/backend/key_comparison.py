"""Conservative key specifications from approved records; never align arbitrary sentences."""
import re

# Feature statements only: not arbitrary table numbers or oscillator frequencies.
from .feature_specs import RULES

KEYS = {'resistance','capacitance','inductance','tolerance','rated_voltage','rated_current','rated_power','power_rating','package','pin_count','supply_voltage','operating_temperature','bandwidth','gain_bandwidth','slew_rate','input_offset_voltage','offset_voltage','gain_bandwidth_product','input_bias_current'}

def key_parameters(component):
    found = {}
    def add(key, name, value, unit, source, scope):
        value = re.sub(r'\s+', ' ', str(value)).strip()
        value = re.sub(r'\s*-?K(?:bytes?|B)\b', ' KB', value, flags=re.I)
        value = re.sub(r'(?<=\d)\s*V\s+to', ' to', value)
        value = re.sub(r'\s+', ' ', value).strip()
        value = re.sub(r'^up to\b', 'up to', value, flags=re.I)
        if not value or len(value)>100: return
        entry = found.setdefault(key, {'component_id':component['component_id'], 'parameter_id':key,
            'canonical_name':key,'name':name,'unit':unit or '', 'value':value,'sources':[], 'scope':scope})
        if entry['value'] != value or entry['unit'] != (unit or ''):
            variants=entry.setdefault('variants',[entry['value']])
            if value not in variants: variants.append(value)
            entry['value']=' / '.join(variants) if len(' / '.join(variants))<=100 else 'Multiple variants — see source'
            entry['ambiguous']=True
        if source and source not in entry['sources']: entry['sources'].append(source)
    for p in component['parameters']:
        key=re.sub(r'[^a-z0-9]+','_',p['canonical_name'].lower()).strip('_')
        if key in KEYS and not p.get('source',{}).get('task_id'):
            add(key,p['name'],p['value'],p['unit'],None,'Reviewed specification')
        # Preserve each approved source separately; merged table strings are not feature statements.
        sources=p.get('sources') or [dict(p.get('source') or {},raw_value=p['value'])]
        for source in sources:
            page=source.get('page')
            raw_original=str(source.get('raw_value') or '')
            source_name=re.sub(r'^\[Source\]\s*','',source.get('raw_name') or p.get('name',p['canonical_name']),flags=re.I)
            source_name=re.sub(r'\s*\(\d+\)$','',source_name)
            source_key=re.sub(r'[^a-z0-9]+','_',source_name.lower()).strip('_')
            if source_key in KEYS: key=source_key
            if key in KEYS and '|' in raw_original:
                labels=re.findall(r'(?i)\b(Min|Typ|Max):\s*([^|\n]+)',raw_original)
                units=re.findall(r'(?i)\bUnit:\s*([^|\n]+)',raw_original)
                clean=[f'{label.title()}: {value.strip()}' for label,value in labels if re.fullmatch(r'[+−-]?\d+(?:\.\d+)?',value.strip())]
                if clean:
                    add(key,source_name,'; '.join(dict.fromkeys(clean)),units[-1].strip() if units else p['unit'],source,'Datasheet test conditions — check source')
            if page is None or page>3: continue
            raw=str(source.get('raw_value') or '')
            raw=re.sub(r'\s+', ' ', raw.replace('®','').replace('–','-')).strip()
            if len(raw)>1000 or '|' in raw: continue
            for key,name,pattern in RULES:
                for m in re.finditer(pattern,raw,re.I):
                    value=m.group(1)
                    if key=='cpu_frequency' and re.search(r'oscillator|crystal|SPI|USB|ADC',raw,re.I): continue
                    if key=='core': value=re.sub(r'Cortex[ -]*','Cortex-',value,flags=re.I)
                    if key=='adc_resolution': value+=' bit'
                    add(key,name,value,'',source,'Datasheet family / feature summary; verify ordering variant')
    return list(found.values())

def build_comparison(items):
    compact=[dict(c,parameters=key_parameters(c)) for c in items]
    keys={p['parameter_id']:p for c in compact for p in c['parameters']}
    rows=[]
    for key,p in keys.items():
        values=[next((v for v in c['parameters'] if v['parameter_id']==key),None) for c in compact]
        present=[v for v in values if v is not None]
        uncertain=any(v.get('ambiguous') or v['scope'].startswith('Datasheet') for v in present)
        different=len(present)>=2 and not uncertain and len({(v['value'],v['unit']) for v in present})>1
        status='Check variant / conditions' if uncertain else ('Different' if different else ('Not extracted' if len(present)<len(items) else 'Matching'))
        rows.append(dict(parameter_id=key,canonical_name=key,name=p['name'],unit='',values=values,
            missing_component_ids=[c['component_id'] for c,v in zip(items,values) if v is None],different=different,status=status))
    return {'components':compact,'rows':rows,'mode':'key_specifications'}

