"""Idempotent upgrade for English catalogues and complete-task publication."""
CATEGORIES = {
    '电阻': 'Resistor', '电容': 'Capacitor', '电感': 'Inductor',
    '二极管': 'Diode', '三极管': 'Transistor', '集成电路': 'Integrated Circuit',
    '连接器': 'Connector', '晶振': 'Crystal', '传感器': 'Sensor',
    'ic': 'Integrated Circuit', 'integrated circuit': 'Integrated Circuit',
    'mcu': 'Integrated Circuit', 'microcontroller': 'Integrated Circuit',
    'bjt': 'Transistor', 'other': 'Other', 'mosfet': 'MOSFET',
}


def upgrade(db):
    # Preserve IDs and references; aliases remain accepted as input only.
    for old, new in CATEGORIES.items():
        row = db.execute('SELECT category_id FROM category WHERE name=?', (old,)).fetchone()
        if row and not db.execute('SELECT 1 FROM category WHERE name=?', (new,)).fetchone():
            db.execute('UPDATE category SET name=?,description=? WHERE category_id=?',
                       (new, new, row[0]))
        db.execute('UPDATE extraction_task SET extracted_category=? WHERE extracted_category=?', (new, old))
    db.execute("INSERT OR IGNORE INTO category(name,description) VALUES('Other','Other components')")
    db.execute('UPDATE category SET description=name')
    db.execute("UPDATE parameter_def SET display_name=canonical_name,description=canonical_name WHERE canonical_name NOT GLOB 'source_*'")
    for name, unit, kind in [
        ('Threshold Voltage', 'V', 'numeric'), ('Supply Voltage', 'V', 'numeric'),
        ('Storage Temperature', '°C', 'text'), ('Junction Temperature', '°C', 'text'),
        ('Package', None, 'text'), ('Clock Frequency', 'Hz', 'numeric'),
        ('Memory', None, 'text'), ('Interface', None, 'text'),
    ]:
        db.execute('INSERT OR IGNORE INTO parameter_def(canonical_name,display_name,unit,data_type,description) VALUES(?,?,?,?,?)',
                   (name, name, unit, kind, name))
    db.commit()
    db.executescript('''
    DROP TRIGGER IF EXISTS trg_audit_auditor_only;
    CREATE TRIGGER trg_audit_auditor_only BEFORE INSERT ON audit_log
    WHEN NOT EXISTS (SELECT 1 FROM users WHERE user_id=NEW.auditor_id
                     AND role IN ('admin','auditor') AND is_active=1)
    BEGIN SELECT RAISE(ABORT,'An active administrator or auditor is required'); END;
    DROP TRIGGER IF EXISTS trg_audit_requires_component;
    DROP TRIGGER IF EXISTS trg_audit_apply;
    CREATE TRIGGER trg_audit_apply AFTER INSERT ON audit_log BEGIN
      UPDATE extraction_param SET
        review_status=CASE NEW.action WHEN 'approve' THEN 'approved' ELSE 'rejected' END,
        reviewed_by=NEW.auditor_id, reviewed_time=NEW.audit_time, review_comment=NEW.comment
      WHERE extraction_param_id=NEW.extraction_param_id;
    END;
    ''')
