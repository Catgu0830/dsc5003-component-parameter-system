"""Real browser regression against an isolated test server (requires Playwright + Edge)."""
import threading
import pytest
from werkzeug.serving import make_server


def test_english_review_browser(app,tmp_path):
    playwright=pytest.importorskip('playwright.sync_api')
    server=make_server('127.0.0.1',0,app,threaded=True)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    from backend.worker import start_worker
    stop, worker = start_worker(app)
    errors=[]
    try:
        with playwright.sync_playwright() as pw:
            browser=pw.chromium.launch(channel='msedge',headless=True)
            page=browser.new_page(viewport={'width':1440,'height':1000})
            page.on('pageerror',lambda e:errors.append(str(e)))
            page.goto(f'http://127.0.0.1:{server.server_port}/legacy')
            page.get_by_label('Username',exact=True).fill('adm1')
            page.get_by_label('Password',exact=True).fill('Passw0rd!')
            page.get_by_role('button',name='Sign in',exact=True).click()
            page.get_by_role('heading',name='Extraction tasks',exact=True).wait_for()
            for i in range(2):
                page.get_by_role('button',name='Upload',exact=True).first.click()
                page.get_by_label('Model',exact=True).fill(f'BROWSER-{i}')
                page.get_by_label('Manufacturer',exact=True).fill('Demo Electronics')
                page.get_by_role('button',name='Create review task',exact=True).click()
                page.get_by_role('heading',name='Parameter review',exact=True).wait_for()
                page.locator('.review-card').first.get_by_role('button',name='Save draft',exact=True).click()
                page.get_by_text('Draft saved and recorded in the activity log.',exact=True).wait_for()
                page.locator('.review-card').first.get_by_role('button',name='Approve',exact=True).click()
                page.get_by_text('Parameter approved. Publication occurs only when all parameters are resolved.',exact=True).wait_for()
                assert page.get_by_text('Not published. All parameters must be resolved before publication.',exact=True).count()==1
                page.locator('.review-card').first.get_by_role('button',name='Approve',exact=True).click()
                page.get_by_text('Published component:',exact=False).wait_for()
            # Batch classification and decisions stay scoped to the current filter/file.
            page.get_by_role('button',name='Upload',exact=True).first.click()
            page.get_by_label('Model',exact=True).fill('BATCH-REVIEW')
            page.get_by_label('Manufacturer',exact=True).fill('Demo Electronics')
            page.get_by_label('Specifications (one English parameter name: original value per line)',exact=True).fill('Supply Voltage: 4–6 V\nOperating Temperature: -40 to 85 °C\nUnknown extra: 123')
            page.get_by_role('button',name='Create review task',exact=True).click()
            page.get_by_role('heading',name='Parameter review',exact=True).wait_for()
            page.get_by_role('button',name='Select filtered pending',exact=True).click()
            page.get_by_role('button',name='Approve selected',exact=True).click()
            page.get_by_text('Some selected records need a classification.',exact=False).wait_for()
            page.get_by_label('Mapping',exact=True).select_option('mapped')
            page.get_by_role('button',name='Select filtered pending',exact=True).click()
            page.get_by_role('button',name='Approve selected',exact=True).click()
            page.get_by_text('2 of 2 records processed.',exact=True).wait_for()
            assert page.get_by_text('Not published. All parameters must be resolved before publication.',exact=True).count()==1
            page.get_by_role('button',name='Select filtered pending',exact=True).click()
            page.get_by_label('Batch review comment',exact=True).fill('Not a useful specification')
            page.get_by_role('button',name='Reject selected',exact=True).click()
            page.get_by_text('1 of 1 records processed.',exact=True).wait_for()
            page.get_by_text('Published component:',exact=False).wait_for()
            page.get_by_role('button',name='Audit Log',exact=True).click()
            page.get_by_role('heading',name='Saved drafts and identity changes (latest 50)',exact=True).wait_for()
            assert page.get_by_text('save_parameter_draft',exact=True).count()==2
            page.get_by_role('button',name='Compare',exact=True).click()
            page.get_by_role('checkbox').nth(0).check();page.get_by_role('checkbox').nth(1).check()
            page.get_by_role('button',name='Start comparison',exact=True).click()
            page.get_by_role('heading',name='Comparison results',exact=True).wait_for()
            assert page.get_by_text('Supply Voltage',exact=True).count()==1
            for fmt in ['CSV','XLSX','JSON']:
                with page.expect_download() as info:
                    page.get_by_role('button',name='Export '+fmt,exact=True).click()
                info.value.save_as(tmp_path/('comparison.'+fmt.lower()))
                assert (tmp_path/('comparison.'+fmt.lower())).stat().st_size>10
            page.get_by_role('button',name='Users',exact=True).click()
            page.get_by_label('Username',exact=True).fill('browser_auditor')
            page.get_by_label('Password (at least 8 characters)',exact=True).fill('BrowserPass12!')
            page.get_by_label('Role',exact=True).select_option('auditor')
            page.get_by_role('button',name='Create account',exact=True).click()
            page.get_by_text('Account created.',exact=True).wait_for()
            assert page.get_by_text('browser_auditor',exact=True).count()==1
            page.get_by_role('button',name='Sign out',exact=True).click()
            page.get_by_role('heading',name='Sign in',exact=True).wait_for()
            page.get_by_label('Username',exact=True).fill('browser_auditor')
            page.get_by_label('Password',exact=True).fill('BrowserPass12!')
            page.get_by_role('button',name='Sign in',exact=True).click()
            page.get_by_role('heading',name='Extraction tasks',exact=True).wait_for()
            assert page.get_by_role('button',name='Users',exact=True).count()==0
            import pymupdf
            doc=pymupdf.open();p=doc.new_page()
            p.insert_text((50,50),'Model: BROWSER-PDF\nManufacturer: Demo Electronics\nCategory: ic\nVoltage:3.3V\nGain:20dB\nPackage:SOT-23')
            pdf=tmp_path/'browser.pdf';doc.save(pdf);doc.close()
            page.get_by_role('button',name='Upload',exact=True).first.click()
            page.get_by_label('File',exact=True).set_input_files(str(pdf))
            page.get_by_role('button',name='Upload',exact=True).last.click()
            page.get_by_role('heading',name='Parameter review',exact=True).wait_for()
            first=page.locator('.review-card').first
            first.get_by_text('Source evidence',exact=False).click()
            with page.expect_download() as info:
                first.get_by_role('button',name='Open source page',exact=True).click()
            assert info.value.suggested_filename.endswith('.png')
            first.get_by_role('button',name='Approve',exact=True).click()
            page.get_by_text('Parameter approved. Publication occurs only when all parameters are resolved.',exact=True).wait_for()
            first=page.locator('.review-card').first
            first.get_by_text('No matching definition? Create an English classification',exact=True).click()
            first.get_by_label('New parameter name',exact=True).fill('Gain')
            first.get_by_label('Standard unit (optional)',exact=True).fill('dB')
            first.get_by_role('button',name='Create definition',exact=True).click()
            page.get_by_text('Definition created; now save or approve this parameter.',exact=True).wait_for()
            first.get_by_role('button',name='Approve',exact=True).click()
            page.get_by_text('Parameter approved. Publication occurs only when all parameters are resolved.',exact=True).wait_for()
            first=page.locator('.review-card').first
            first.get_by_label('Review comment',exact=True).fill('Package already recorded in identity')
            first.get_by_role('button',name='Reject',exact=True).click()
            page.get_by_text('Published component:',exact=False).wait_for()
            page.screenshot(path=str(tmp_path/'english-ui.png'),full_page=True)
            assert not errors,errors
            browser.close()
    finally:
        stop.set();worker.join(timeout=5)
        server.shutdown();thread.join(timeout=5)
