import threading
import pytest
from werkzeug.serving import make_server


def test_basic_admin_and_user_pages(app):
    pwmod=pytest.importorskip('playwright.sync_api')
    server=make_server('127.0.0.1',0,app,threaded=True);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        with pwmod.sync_playwright() as pw:
            browser=pw.chromium.launch(channel='msedge',headless=True);page=browser.new_page();errors=[]
            page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept())
            base=f'http://127.0.0.1:{server.server_port}'
            def go(name):page.goto(base+'/frontend/pages/'+name+'.html');page.wait_for_load_state('networkidle')
            def login(user,password='Passw0rd!'):
                page.goto(base+'/frontend/login.html');page.locator('#username').fill(user);page.locator('#password').fill(password);page.locator('#loginButton').click();page.wait_for_url('**/dashboard.html')
            login('adm1')
            for name in ['dashboard','extraction','tasks','components','comparison','audit','logs']:
                go(name)
                assert not page.locator('.error').filter(has_text='Unable to').count(),name
            go('users');page.locator('#newUsername').fill('new_auditor');page.locator('#newPassword').fill('NewPassword12!');page.locator('#newRole').select_option('auditor');page.locator('#createUserForm button[type=submit]').click()
            page.get_by_text('User created.',exact=True).wait_for()
            userrow=page.locator('#userTableBody tr').filter(has_text='new_auditor');userrow.locator('select').select_option('user');userrow.get_by_role('button',name='Save',exact=True).click();page.get_by_text('User new_auditor updated.',exact=True).wait_for()
            go('manufacturers');page.locator('#manufacturerName').fill('QA Manufacturer');page.locator('#manufacturerForm button[type=submit]').click();page.get_by_text('Manufacturer created.',exact=True).wait_for()
            mrow=page.locator('#manufacturerTableBody tr').last;mrow.locator('input').nth(1).fill('QA');mrow.get_by_role('button',name='Save',exact=True).click();page.get_by_text('Manufacturer updated.',exact=True).wait_for()
            go('components-admin');page.locator('#componentModel').fill('QA-COMPONENT');page.locator('#componentManufacturer').fill('QA Manufacturer');page.locator('#componentCategory').select_option('Resistor');page.locator('#componentForm button[type=submit]').click();page.get_by_text('Component created.',exact=True).wait_for()
            page.locator('#componentTableBody tr').filter(has_text='QA-COMPONENT').get_by_role('button',name='Edit',exact=True).click();page.locator('#componentPackage').fill('0603');page.locator('#componentForm button[type=submit]').click();page.get_by_text('Component updated.',exact=True).wait_for()
            go('components');page.locator('#keyword').fill('QA-COMPONENT');page.locator('#searchForm button[type=submit]').click();page.locator('#componentTable tr').filter(has_text='QA-COMPONENT').wait_for()
            go('components-admin');page.locator('#componentTableBody tr').filter(has_text='QA-COMPONENT').get_by_role('button',name='Delete',exact=True).click();page.get_by_text('Component deleted.',exact=True).wait_for()
            go('manufacturers');page.locator('#manufacturerTableBody tr').last.get_by_role('button',name='Delete',exact=True).click();page.get_by_text('Manufacturer deleted.',exact=True).wait_for()
            go('extraction');page.locator('[data-tab=manualPanel]').click()
            page.locator('#manualModel').fill('MANUAL-RANGE');page.locator('#manualManufacturer').fill('Example');page.locator('#manualCategory').select_option('Integrated Circuit')
            page.locator('.parameter-name').first.fill('Supply Voltage');page.locator('.parameter-value').first.fill('4–6');page.locator('.parameter-unit').first.fill('V')
            page.locator('#manualForm button[type=submit]').click()
            page.wait_for_function("document.querySelector('#taskStatus').textContent.trim().toLowerCase().includes('success')")
            page.locator('#reviewFileLink').click();page.locator('#approveFile').wait_for(state='visible');page.locator('#approveFile').click()
            page.wait_for_function("document.querySelector('#listMessage').textContent.includes('File approved.')")
            go('dashboard');page.locator('#logoutButton').click();page.wait_for_url('**/login.html')
            login('new_auditor','NewPassword12!');go('audit');page.wait_for_url('**/dashboard.html')
            go('users');page.get_by_text('Only administrators can manage users.',exact=True).wait_for();assert page.locator('#backHome').is_enabled();page.locator('#backHome').click();page.wait_for_url('**/dashboard.html')
            # A stale role cache must not expose administrator controls.
            page.evaluate("localStorage.setItem('currentUser',JSON.stringify({role:'admin'}))")
            go('users');page.get_by_text('Only administrators can manage users.',exact=True).wait_for()
            # Invalid sessions return to login instead of leaving a broken screen.
            page.evaluate("localStorage.setItem('token','invalid')");go('components');page.wait_for_url('**/login.html')
            assert not errors,errors
            browser.close()
    finally:server.shutdown();thread.join(timeout=5)
