import threading
from pathlib import Path
import pytest
from werkzeug.serving import make_server


def test_supplied_frontend_real_file_review(app,tmp_path):
    pwmod=pytest.importorskip('playwright.sync_api')
    corpus=Path('E:/CityU Files/DS5003/元件/Datasheets_original_copy_precise/Analog')
    if not (corpus/'ad8675.pdf').exists():pytest.skip('Local real datasheets unavailable')
    from backend.worker import start_worker
    from backend.db import get_db
    server=make_server('127.0.0.1',0,app,threaded=True)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    stop,worker=start_worker(app);errors=[]
    try:
        with pwmod.sync_playwright() as pw:
            browser=pw.chromium.launch(channel='msedge',headless=True)
            page=browser.new_page(viewport={'width':1600,'height':1000});page.on('pageerror',lambda e:errors.append(str(e)))
            page.on('dialog',lambda d:d.accept())
            base=f'http://127.0.0.1:{server.server_port}'
            page.goto(base+'/');page.locator('#username').fill('adm1');page.locator('#password').fill('Passw0rd!');page.locator('#loginButton').click()
            page.wait_for_url('**/dashboard.html')
            for filename in ['ad8675.pdf','ad8676.pdf']:
                page.goto(base+'/frontend/pages/extraction.html')
                page.locator('#uploadFile').set_input_files(str(corpus/filename))
                page.get_by_role('button',name='Upload and Start Extraction').click()
                page.wait_for_function("document.querySelector('#taskStatus').textContent.trim().toLowerCase().includes('success')",timeout=30000)
                page.goto(base+'/frontend/pages/audit.html')
                page.locator('#pendingBody tr').filter(has_text=filename).get_by_role('button',name='Review File').click()
                page.locator('#approveFile').wait_for(state='visible')
                assert page.locator('#paramBody tr').count()>0
                # One document-level decision, without mapping each original field.
                page.locator('#approveFile').click()
                page.wait_for_function("document.querySelector('#listMessage').textContent.includes('File approved.')")
                assert page.locator('#pendingBody').get_by_text(filename,exact=True).count()==0
            # Reject a complete real PDF without touching the existing library.
            page.goto(base+'/frontend/pages/extraction.html')
            page.locator('#uploadFile').set_input_files(str(corpus/'ad8675.pdf'))
            page.get_by_role('button',name='Upload and Start Extraction').click()
            page.wait_for_function("document.querySelector('#taskStatus').textContent.trim().toLowerCase().includes('success')",timeout=30000)
            page.goto(base+'/frontend/pages/audit.html')
            page.locator('#pendingBody tr').filter(has_text='ad8675.pdf').get_by_role('button',name='Review File').click()
            page.locator('#fileComment').fill('Duplicate document, not needed')
            page.locator('#rejectFile').click()
            page.wait_for_function("document.querySelector('#listMessage').textContent.includes('File rejected.')")
            page.goto(base+'/frontend/pages/comparison.html')
            page.locator('#componentSelectionBody input[type=checkbox]').first.wait_for()
            page.locator('#componentSelectionBody input[type=checkbox]').nth(0).check();page.locator('#componentSelectionBody input[type=checkbox]').nth(1).check()
            page.locator('#compareButton').click();page.locator('#comparisonBody tr').first.wait_for()
            for fmt in ['csv','xlsx','json']:
                with page.expect_download() as info:page.locator('[data-format='+fmt+']').click()
                info.value.save_as(tmp_path/('comparison.'+fmt))
                assert (tmp_path/('comparison.'+fmt)).stat().st_size>100
            page.screenshot(path=str(tmp_path/'supplied-comparison.png'),full_page=True)
            page.goto(base+'/frontend/pages/tasks.html')
            page.locator('#tasksTableBody button').filter(has_text='View Details').first.click()
            page.locator('#detailComponents').get_by_text('AD8675',exact=False).first.wait_for()
            with page.expect_download() as info:page.locator('#downloadSource').click()
            assert info.value.suggested_filename.endswith('.pdf')
            page.goto(base+'/frontend/pages/components.html')
            page.locator('#componentTable button').filter(has_text='View Details').first.click()
            page.locator('#detailPanel').wait_for(state='visible')
            for fmt in ['CSV','XLSX','JSON']:
                with page.expect_download() as info:page.locator('#detailContent').get_by_role('button',name=fmt,exact=True).click()
                info.value.save_as(tmp_path/('component.'+fmt.lower()))
            assert not errors,errors
            browser.close()
        with app.app_context():
            db=get_db()
            assert db.execute('SELECT COUNT(*) FROM component').fetchone()[0]==2
            assert db.execute("SELECT COUNT(*) FROM operation_log WHERE action='approve_file'").fetchone()[0]==2
            assert db.execute("SELECT COUNT(*) FROM operation_log WHERE action='reject_file'").fetchone()[0]==1
            assert db.execute("SELECT COUNT(*) FROM extraction_param WHERE review_status='pending'").fetchone()[0]==0
    finally:
        stop.set();worker.join(timeout=5);server.shutdown();thread.join(timeout=5)
