from backend.pdf_specs import standard_table_excerpts, EXCLUDE
from backend.normalization import normalize_component
from backend.catalog import load_catalog


def line(text,x,y):
    return text,[x,y,x+len(text)*3,y+8]


def test_grade_rows_and_conditions_are_not_lost():
    lines=[line('VS = ±5.0 V, TA = +25°C',50,10)]
    for name,x in [('Parameter',50),('Symbol',200),('Conditions',270),('Min',400),('Typ',450),('Max',500),('Unit',550)]:
        lines.append(line(name,x,30))
    lines += [line('Offset Voltage',60,50),line('VOS',200,50),
              line('B Grade (SOIC)',70,65),line('12',450,65),line('50',500,65),line('μV',550,65),
              line('A Grade (MSOP)',70,80),line('100',500,80),line('μV',550,80),
              line('Input Bias Current',60,95),line('IB',200,95),line('-2',400,95),line('+2',500,95),line('nA',550,95),
              line('-40°C to +125°C',270,110),line('-5.5',400,110),line('+5.5',500,110),line('nA',550,110)]
    records=standard_table_excerpts(lines,3)
    assert len(records)==2
    value=records[0]['value_text']
    assert 'VS = ±5.0 V' in value
    assert 'B Grade (SOIC) | Typ: 12 | Max: 50' in value
    assert 'A Grade (MSOP) | Max: 100' in value
    assert 'Min: 12' not in value
    assert 'Min: -5.5 | Max: +5.5' in records[1]['value_text']


def test_double_digit_figure_captions_are_excluded():
    assert EXCLUDE.search('Figure 23. Voltage Noise (0.1 Hz to 10 Hz)')
    assert EXCLUDE.search('Table 1. Voltage Noise')
    assert not EXCLUDE.search('Voltage Noise Density')


def test_source_context_survives_normalization(app):
    with app.app_context():
        c=normalize_component({'model':'TEST','manufacturer':'Test','category':'ic',
          'specifications':[{'label':'Offset Voltage','value_text':'Typ: 10; Max: 75 μV',
            'source':{'page':3,'snippet':'10 | 75 | μV','context':'VS = ±5 V; Min | Typ | Max | Unit'}}]},load_catalog())
        assert 'VS = ±5 V' in c['parameters'][0]['source']['snippet']
        assert 'Min | Typ | Max' in c['parameters'][0]['source']['snippet']


def test_repeated_centered_headers_do_not_become_parameters():
    lines=[]
    for y in (30,100):
        for name,x in [('Parameter',50),('Description',150),('Min',300),('Typ',350),('Max',400),('Unit',450)]:
            lines.append(line(name,x,y))
    lines += [line('Voltage',50,50),line('2',290,50),line('3',350,50),line('5',400,50),line('V',450,50),
              line('RF power control range',150,120),line('-24',290,120),line('0',350,120),line('20',400,120),line('dBm',450,120)]
    records=standard_table_excerpts(lines,1)
    assert [r['label'] for r in records]==['Voltage','RF power control range']
    assert 'Min: -24' in records[1]['value_text']
    assert 'Parameter: Parameter' not in records[1]['value_text']


def test_subsequent_table_without_typ_uses_its_own_columns():
    lines=[]
    for name,x in [('Parameter',50),('Description',150),('Min',300),('Typ',350),('Max',400),('Unit',450)]:
        lines.append(line(name,x,30))
    lines += [line('Voltage',50,50),line('2',300,50),line('3',350,50),line('5',400,50),line('V',450,50)]
    for name,x in [('Parameter',50),('Description',150),('Min',350),('Max',400),('Unit',450)]:
        lines.append(line(name,x,100))
    lines += [line('ADC error',150,120),line('-7',350,120),line('7',400,120),line('mV',450,120)]
    records=standard_table_excerpts(lines,1)
    assert len(records)==2
    assert records[1]['label']=='ADC error'
    assert 'Min: -7' in records[1]['value_text'] and 'Max: 7' in records[1]['value_text']
    assert 'Typ:' not in records[1]['value_text']
    assert 'Voltage' not in records[1]['source']['context']
