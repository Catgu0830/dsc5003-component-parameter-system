import io
import re
import pytest


def make_task(client, headers, model='TEST-RANGE'):
    r = client.post('/api/tasks', headers=headers, json={'source_type':'manual','component':{
        'model':model,'manufacturer':'Demo Electronics','category':'ic',
        'specifications':[{'label':'Supply Voltage','value_text':'4–6 V'},
                          {'label':'Operating Temperature','value_text':'-40 to 85 °C'}]}})
    assert r.status_code == 202, r.get_json()
    task_id=r.get_json()['data']['task_id']
    d=client.get(f'/api/tasks/{task_id}',headers=headers).get_json()['data']
    return task_id,d['result']['components'][0]['parameters']


@pytest.mark.parametrize('reviewer',['adm1','aud1'])
def test_complete_review_only_publishes(client,auth,reviewer):
    user=auth('usr1');review=auth(reviewer)
    tid,ps=make_task(client,user)
    for i,p in enumerate(ps):
        r=client.post(f"/api/audit/params/{p['extraction_param_id']}",headers=review,
                      json={'action':'approve','preserve_text':True})
        assert r.status_code==200,r.get_json()
        data=client.get('/api/components',headers=user).get_json()['data']
        assert data['total']==(1 if i==len(ps)-1 else 0)
    c=data['items'][0]
    assert c['category']=='Integrated Circuit'
    assert any(p['value']=='4–6 V' for p in c['parameters'])
    assert all(not re.search('[\u4e00-\u9fff]',p['name']) for p in c['parameters'])
    assert client.get('/api/audit/logs',headers=review).get_json()['data']['total']==2
    assert client.post(f"/api/audit/params/{ps[0]['extraction_param_id']}",headers=review,json={'action':'approve'}).status_code==409
    for fmt in ['json','csv','xlsx']:
        assert client.get(f"/api/export/components/{c['component_id']}?format={fmt}",headers=user).status_code==200


def test_save_draft_permission_and_log(client,auth):
    user=auth('usr1');admin=auth('adm1');tid,ps=make_task(client,user)
    url=f"/api/audit/params/{ps[0]['extraction_param_id']}"
    assert client.put(url,headers=user,json={}).status_code==403
    r=client.put(url,headers=admin,json={'raw_value':'4 to 6 V','preserve_text':True})
    assert r.status_code==200,r.get_json()
    assert r.get_json()['data']['review_status']=='pending'
    assert client.get('/api/components',headers=user).get_json()['data']['total']==0
    activity=client.get('/api/audit/activity',headers=admin).get_json()['data']['items']
    assert activity[0]['action']=='save_parameter_draft'
    assert activity[0]['detail']['after']['raw_value']=='4 to 6 V'


def test_last_rejection_publishes_approved_only(client,auth):
    user=auth('usr1');admin=auth('adm1');tid,ps=make_task(client,user)
    assert client.post(f"/api/audit/params/{ps[0]['extraction_param_id']}",headers=admin,json={'action':'approve','preserve_text':True}).status_code==200
    assert client.post(f"/api/audit/params/{ps[1]['extraction_param_id']}",headers=admin,json={'action':'reject','comment':'Not applicable'}).status_code==200
    c=client.get('/api/components',headers=user).get_json()['data']['items'][0]
    assert len(c['parameters'])==1


def test_all_rejected_never_publishes(client,auth):
    user=auth('usr1');admin=auth('adm1');tid,ps=make_task(client,user)
    for p in ps:
        assert client.post(f"/api/audit/params/{p['extraction_param_id']}",headers=admin,json={'action':'reject','comment':'Wrong variant'}).status_code==200
    assert client.get('/api/components',headers=user).get_json()['data']['total']==0


def test_custom_definition_and_accounts(client,auth):
    admin=auth('adm1');user=auth('usr1')
    for role in ['admin','auditor','user']:
        r=client.post('/api/users',headers=admin,json={'username':'new_'+role,'password':'NewPassword12!','role':role})
        assert r.status_code==201,r.get_json()
        login=client.post('/api/auth/login',json={'username':'new_'+role,'password':'NewPassword12!'})
        assert login.get_json()['data']['user']['role']==role
    assert client.post('/api/users',headers=user,json={'username':'hacker','password':'Passw0rd!','role':'admin'}).status_code==403
    r=client.post('/api/parameters',headers=admin,json={'canonical_name':'Input Hysteresis','unit':'V','data_type':'text'})
    assert r.status_code==201
    assert client.post('/api/parameters',headers=admin,json={'canonical_name':'中文参数'}).status_code==400


def test_explicit_pdf_metadata_short_values(app,client,auth,tmp_path):
    import pymupdf
    from backend.pdf_specs import extract_pdf
    from backend.worker import process_one
    doc=pymupdf.open();page=doc.new_page()
    page.insert_text((50,50),'Model: DEMO-LDO33\nManufacturer: Demo Electronics\nCategory: ic\nVoltage:3.3V\nCurrent:500mA\nPackage:SOT-23',fontsize=12)
    data=doc.tobytes();path=tmp_path/'demo.pdf';path.write_bytes(data)
    extracted=extract_pdf(path)
    assert extracted['model']=='DEMO-LDO33'
    assert extracted['manufacturer']=='Demo Electronics'
    assert extracted['category']=='ic'
    assert {'Voltage','Current','Package'} <= {s['label'] for s in extracted['specifications']}
    user=auth('usr1')
    r=client.post('/api/tasks/upload',headers=user,data={'file':(io.BytesIO(data),'demo.pdf')})
    assert r.status_code==202,r.get_json()
    assert process_one(app)
    tid=r.get_json()['data']['task_id']
    result=client.get(f'/api/tasks/{tid}',headers=user).get_json()['data']
    assert result['status']=='success',result
    assert result['extracted_category']=='Integrated Circuit'
    assert result['param_count']>=3
    admin=auth('adm1')
    client.post('/api/users',headers=admin,json={'username':'other_reader','password':'ReaderPass12!','role':'user'})
    login=client.post('/api/auth/login',json={'username':'other_reader','password':'ReaderPass12!'})
    reader={'Authorization':'Bearer '+login.get_json()['data']['token']}
    assert client.get(f'/api/tasks/{tid}/source/page/1',headers=reader).status_code==403
    for p in result['result']['components'][0]['parameters']:
        response=client.post(f"/api/audit/params/{p['extraction_param_id']}",headers=admin,json={'action':'approve','preserve_text':True})
        assert response.status_code==200,response.get_json()
    assert client.get(f'/api/tasks/{tid}/source/page/1',headers=reader).status_code==200
    assert client.get(f'/api/tasks/{tid}',headers=reader).status_code==403
    assert client.get(f'/api/tasks/{tid}/source/page/2',headers=reader).status_code==403


def test_same_classification_preserves_multiple_values(client,auth):
    user=auth('usr1');admin=auth('adm1')
    r=client.post('/api/tasks',headers=user,json={'source_type':'manual','component':{'model':'MULTI','manufacturer':'Demo','category':'ic','specifications':[{'label':'Voltage','value_text':'2 V at 1 mA'},{'label':'Voltage','value_text':'4 V at 5 mA'}]}})
    tid=r.get_json()['data']['task_id']
    ps=client.get(f'/api/tasks/{tid}',headers=user).get_json()['data']['result']['components'][0]['parameters']
    for p in ps:
        assert client.post(f"/api/audit/params/{p['extraction_param_id']}",headers=admin,json={'action':'approve','preserve_text':True}).status_code==200
    p=client.get('/api/components',headers=user).get_json()['data']['items'][0]['parameters'][0]
    assert '2 V at 1 mA' in p['value'] and '4 V at 5 mA' in p['value']
