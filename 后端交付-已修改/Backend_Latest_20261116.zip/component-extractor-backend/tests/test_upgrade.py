from backend.db import init_db, get_db


def test_upgrade_preserves_accounts_and_is_idempotent(app,client,auth):
    init_db(app.config['DATABASE'])
    init_db(app.config['DATABASE'])
    headers=auth('adm1')
    assert client.get('/api/users',headers=headers).get_json()['data']['total']==3
    with app.app_context():
        assert get_db().execute("SELECT COUNT(*) FROM parameter_def WHERE canonical_name='Threshold Voltage'").fetchone()[0]==1
    uid=client.get('/api/auth/me',headers=headers).get_json()['data']['user_id']
    assert client.put('/api/users/'+str(uid),headers=headers,json={'is_active':False}).status_code==409


def test_range_in_numeric_input_becomes_reviewable_text(client,auth):
    user=auth('usr1')
    r=client.post('/api/tasks',headers=user,json={'component':{'model':'RANGE','manufacturer':'Test','category':'IC','parameters':[{'name':'Voltage','value':'4–6 V'}]}})
    assert r.status_code==202,r.get_json()
    tid=r.get_json()['data']['task_id']
    p=client.get(f'/api/tasks/{tid}',headers=user).get_json()['data']['result']['components'][0]['parameters'][0]
    assert p['value_num'] is None and p['raw_value']=='4–6 V'
