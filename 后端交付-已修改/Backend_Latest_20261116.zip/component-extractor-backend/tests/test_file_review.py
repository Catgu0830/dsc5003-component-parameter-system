import pytest


def create(client,h,model='FILE-TEST'):
    r=client.post('/api/tasks',headers=h,json={'source_type':'manual','component':{'model':model,'manufacturer':'Example','category':'ic','specifications':[{'label':'Supply Voltage','value_text':'4–6 V'},{'label':'Special recovery window','value_text':'2–7 ms'}]}})
    assert r.status_code==202,r.get_json()
    tid=r.get_json()['data']['task_id']
    return tid,client.get(f'/api/tasks/{tid}',headers=h).get_json()['data']


@pytest.mark.parametrize('role',['adm1','aud1'])
def test_whole_file_approval_preserves_unmapped(client,auth,role):
    h=auth(role);tid,d=create(client,h)
    payload={'action':'approve','expected_revision':d['review_revision']}
    assert client.post(f'/api/audit/tasks/{tid}/review',headers=auth('usr1'),json=payload).status_code==403
    r=client.post(f'/api/audit/tasks/{tid}/review',headers=h,json=payload)
    assert r.status_code==200,r.get_json()
    d=r.get_json()['data'];assert d['pending_count']==0 and d['approved_count']==2 and d['component_id']
    c=client.get('/api/components/'+str(d['component_id']),headers=h).get_json()['data']
    assert {p['value'] for p in c['parameters']}=={'4–6 V','2–7 ms'}
    assert any(p['name'].startswith('Original:') for p in c['parameters'])
    assert client.post(f'/api/audit/tasks/{tid}/review',headers=h,json=payload).status_code==409
    assert client.get('/api/audit/files/history',headers=h).get_json()['data']['total']==1


def test_file_rollback_revision_exclusions_rejection(client,auth):
    h=auth('adm1');tid,d=create(client,h)
    params=d['result']['components'][0]['parameters'];pid=params[0]['extraction_param_id']
    payload={'action':'approve','expected_revision':d['review_revision'],'edits':[{'extraction_param_id':pid,'raw_value':'5–7 V'},{'extraction_param_id':999999,'raw_value':'bad'}]}
    assert client.post(f'/api/audit/tasks/{tid}/review',headers=h,json=payload).status_code==400
    d=client.get(f'/api/tasks/{tid}',headers=h).get_json()['data']
    assert d['pending_count']==2 and not d['component_id'] and d['result']['components'][0]['parameters'][0]['raw_value']=='4–6 V'
    assert client.get('/api/audit/logs',headers=h).get_json()['data']['total']==0
    assert client.post(f'/api/audit/tasks/{tid}/review',headers=h,json={'action':'approve','expected_revision':'stale'}).status_code==409
    r=client.post(f'/api/audit/tasks/{tid}/review',headers=h,json={'action':'approve','expected_revision':d['review_revision'],'exclude_ids':[params[1]['extraction_param_id']]})
    assert r.status_code==200,r.get_json()
    assert r.get_json()['data']['approved_count']==1 and r.get_json()['data']['rejected_count']==1
    tid,d=create(client,h,'REJECT-TEST')
    assert client.post(f'/api/audit/tasks/{tid}/review',headers=h,json={'action':'reject','expected_revision':d['review_revision']}).status_code==400
    r=client.post(f'/api/audit/tasks/{tid}/review',headers=h,json={'action':'reject','comment':'Wrong document','expected_revision':d['review_revision']})
    assert r.status_code==200 and not r.get_json()['data']['component_id']
    assert r.get_json()['data']['rejected_count']==2
