
/* ========================================
   Audit Management Module
   Component Extraction System
======================================== */

document.addEventListener("DOMContentLoaded", () => {

    // Authentication
    if (!getToken()) {
        window.location.href = "../login.html";
        return;
    }

    // State
    let currentPage = 1;
    let totalPages = 1;

    let logPage = 1;
    let logTotalPages = 1;

    let currentTaskId = null;
    let currentTask = null;
    let originalComponents = [];

    const pendingBody =
        document.getElementById("pendingTableBody");

    const logsBody =
        document.getElementById("auditLogsBody");

    // ------------------------------------
    // Helpers
    // ------------------------------------

    function getData(response) {
        return response?.data ?? response ?? {};
    }

    function getItems(data) {
        return data.items || data.tasks || data.logs || [];
    }

    function getTaskId(task) {
        return task.task_id ?? task.id;
    }

    function getComponents(task) {

        return (
            task.components ||
            task.result?.components ||
            task.result?.data?.components ||
            []
        );

    }

    function formatDate(value) {

        if (!value) return "-";

        const date = new Date(value);

        if (Number.isNaN(date.getTime())) {
            return String(value);
        }

        return date.toLocaleString("en-US");

    }

    function safeText(value) {

        if (value === null || value === undefined || value === "") {
            return "-";
        }

        return String(value);

    }

    function showMessage(id, message, type = "") {

        const element = document.getElementById(id);

        element.textContent = message;

        element.className = "form-message " + type;

    }

    function createCell(row, value) {

        const cell = document.createElement("td");

        cell.textContent = safeText(value);

        row.appendChild(cell);

        return cell;

    }

    function createInfo(container, label, value) {

        const item = document.createElement("div");

        item.className = "audit-info-item";

        const heading = document.createElement("strong");

        heading.textContent = label;

        const content = document.createElement("span");

        content.textContent = safeText(value);

        item.appendChild(heading);

        item.appendChild(content);

        container.appendChild(item);

    }

    function getSource(task) {

        const source = task.source || {};

        return (
            task.source_type ||
            source.source_type ||
            source.type ||
            "-"
        );

    }

    function getAverageConfidence(components) {

        const values = [];

        components.forEach(component => {

            (component.parameters || []).forEach(parameter => {

                if (
                    parameter.confidence !== null &&
                    parameter.confidence !== undefined
                ) {
                    values.push(Number(parameter.confidence));
                }

            });

        });

        if (!values.length) return "-";

        const average =
            values.reduce((sum, value) => sum + value, 0) /
            values.length;

        return `${(average * 100).toFixed(1)}%`;

    }

    // ------------------------------------
    // Load pending reviews
    // ------------------------------------

    async function loadPendingReviews() {

        pendingBody.innerHTML = `
            <tr>
                <td colspan="7">Loading reviews...</td>
            </tr>
        `;

        showMessage("listMessage", "");

        const params = new URLSearchParams({
            page: currentPage,
            page_size: 20
        });

        try {

            const response = await apiRequest(
                `/api/audit/tasks?${params.toString()}`
            );

            const data = getData(response);

            const items = getItems(data);

            const total = Number(data.total ?? items.length);

            const pageSize = Number(data.page_size ?? 20);

            currentPage = Number(data.page ?? currentPage);

            totalPages = Math.max(
                1,
                Math.ceil(total / pageSize)
            );

            renderPendingReviews(items, total);

        } catch (error) {

            pendingBody.innerHTML = `
                <tr>
                    <td colspan="7">Unable to load pending reviews.</td>
                </tr>
            `;

            showMessage(
                "listMessage",
                error.message,
                "error"
            );

            handleAuthError(error);

        }

    }

    // ------------------------------------
    // Render pending review list
    // ------------------------------------

    function renderPendingReviews(items, total) {

        pendingBody.innerHTML = "";

        document.getElementById("pendingCount").textContent =
            total;

        document.getElementById("pendingTotal").textContent =
            `${total} records`;

        document.getElementById("pageInfo").textContent =
            `Page ${currentPage} / ${totalPages}`;

        document.getElementById("prevPage").disabled =
            currentPage <= 1;

        document.getElementById("nextPage").disabled =
            currentPage >= totalPages;

        if (!items.length) {

            pendingBody.innerHTML = `
                <tr>
                    <td colspan="7">No pending reviews found.</td>
                </tr>
            `;

            return;

        }

        items.forEach(task => {

            const row = document.createElement("tr");

            const components = getComponents(task);

            const firstComponent = components[0] || {};

            createCell(row, getTaskId(task));

            createCell(row, getSource(task));

            createCell(
                row,
                firstComponent.model ||
                `${components.length} component(s)`
            );

            createCell(
                row,
                firstComponent.manufacturer || "-"
            );

            createCell(
                row,
                getAverageConfidence(components)
            );

            createCell(
                row,
                formatDate(task.created_time)
            );

            const actionCell = document.createElement("td");

            const button = document.createElement("button");

            button.className = "primary-button";

            button.textContent = "Review";

            button.addEventListener("click", () => {

                openReview(getTaskId(task));

            });

            actionCell.appendChild(button);

            row.appendChild(actionCell);

            pendingBody.appendChild(row);

        });

    }

    // ------------------------------------
    // Load review details
    // ------------------------------------

    async function openReview(taskId) {

        currentTaskId = taskId;

        currentTask = null;

        originalComponents = [];

        const panel =
            document.getElementById("reviewPanel");

        panel.hidden = false;

        panel.scrollIntoView({
            behavior: "smooth"
        });

        document.getElementById("reviewTaskId").textContent =
            `Task ID: ${taskId}`;

        document.getElementById("editableComponents").textContent =
            "Loading component information...";

        document.getElementById("taskInformation").innerHTML = "";

        document.getElementById("sourceInformation").innerHTML = "";

        document.getElementById("validationWarnings").innerHTML = "";

        document.getElementById("reviewComment").value = "";

        document.getElementById("confirmOverwrite").checked = false;

        document.getElementById("expectedRevisions").value = "";

        document.getElementById("approveButton").disabled = false;

        document.getElementById("rejectButton").disabled = false;

        showMessage("detailMessage", "");

        try {

            const response = await apiRequest(
                `/api/audit/tasks/${encodeURIComponent(taskId)}`
            );

            const data = getData(response);

            currentTask = data.task || data;

            originalComponents = JSON.parse(
                JSON.stringify(getComponents(currentTask))
            );

            renderReviewDetails(currentTask);

        } catch (error) {

            document.getElementById("editableComponents").textContent =
                "Unable to load review details.";

            showMessage(
                "detailMessage",
                error.message,
                "error"
            );

            handleAuthError(error);

        }

    }

    // ------------------------------------
    // Render review details
    // ------------------------------------

    function renderReviewDetails(task) {

        const information =
            document.getElementById("taskInformation");

        information.innerHTML = "";

        createInfo(
            information,
            "Task ID",
            getTaskId(task)
        );

        createInfo(
            information,
            "Source Type",
            getSource(task)
        );

        createInfo(
            information,
            "Task Status",
            task.status
        );

        createInfo(
            information,
            "Review Status",
            task.review_status
        );

        createInfo(
            information,
            "Created At",
            formatDate(task.created_time)
        );

        createInfo(
            information,
            "Confidence",
            getAverageConfidence(originalComponents)
        );

        renderSource(task);

        renderComponents(originalComponents);

        renderWarnings(task.warnings || []);

    }

    // ------------------------------------
    // Render source information
    // ------------------------------------

    function renderSource(task) {

        const container =
            document.getElementById("sourceInformation");

        container.innerHTML = "";

        const source = task.source || {};

        createInfo(
            container,
            "Source Type",
            getSource(task)
        );

        createInfo(
            container,
            "Source Location",
            task.source_location ||
            source.location ||
            source.url ||
            task.url
        );

        createInfo(
            container,
            "Original Filename",
            task.original_filename ||
            source.filename ||
            source.original_filename
        );

    }

    // ------------------------------------
    // Parameter source evidence
    // ------------------------------------

    function getEvidence(parameter) {

        const source = parameter.source || {};

        const parts = [];

        if (source.location) {
            parts.push(source.location);
        }

        if (source.page !== undefined) {
            parts.push(`Page ${source.page}`);
        }

        if (source.row !== undefined) {
            parts.push(`Row ${source.row}`);
        }

        if (source.snippet) {
            parts.push(source.snippet);
        }

        return parts.join(" | ") || "No source evidence";

    }

    // ------------------------------------
    // Render editable components
    // ------------------------------------

    function renderComponents(components) {

        const container =
            document.getElementById("editableComponents");

        container.innerHTML = "";

        if (!components.length) {

            container.textContent =
                "No extracted components found.";

            return;

        }

        components.forEach((component, componentIndex) => {

            const card = document.createElement("div");

            card.className = "audit-component-card";

            const heading = document.createElement("h3");

            heading.textContent =
                component.model || `Component ${componentIndex + 1}`;

            card.appendChild(heading);

            const metadata = document.createElement("p");

            metadata.className = "panel-description";

            metadata.textContent =
                `Manufacturer: ${safeText(component.manufacturer)} | Category: ${safeText(component.category)}`;

            card.appendChild(metadata);

            const parameters = component.parameters || [];

            if (!parameters.length) {

                const empty = document.createElement("p");

                empty.textContent = "No parameters found.";

                card.appendChild(empty);

            } else {

                const wrapper = document.createElement("div");

                wrapper.className = "audit-parameter-wrapper";

                const table = document.createElement("table");

                table.className = "audit-parameter-table";

                const thead = document.createElement("thead");

                thead.innerHTML = `
                    <tr>
                        <th>Parameter Name</th>
                        <th>Parameter Value</th>
                        <th>Unit</th>
                        <th>Confidence</th>
                        <th>Source Evidence</th>
                    </tr>
                `;

                table.appendChild(thead);

                const tbody = document.createElement("tbody");

                parameters.forEach((parameter, parameterIndex) => {

                    const row = document.createElement("tr");

                    const nameCell = document.createElement("td");

                    const nameInput = document.createElement("input");

                    nameInput.type = "text";

                    nameInput.className = "audit-edit-input";

                    nameInput.value = parameter.name || "";

                    nameInput.dataset.componentIndex = componentIndex;

                    nameInput.dataset.parameterIndex = parameterIndex;

                    nameInput.dataset.field = "name";

                    nameCell.appendChild(nameInput);

                    row.appendChild(nameCell);

                    const valueCell = document.createElement("td");

                    const valueInput = document.createElement("input");

                    valueInput.type = "text";

                    valueInput.className = "audit-edit-input";

                    valueInput.value = safeText(
                        parameter.value ??
                        parameter.value_num ??
                        parameter.value_text
                    );

                    valueInput.dataset.componentIndex = componentIndex;

                    valueInput.dataset.parameterIndex = parameterIndex;

                    valueInput.dataset.field = "value";

                    valueCell.appendChild(valueInput);

                    row.appendChild(valueCell);

                    const unitCell = document.createElement("td");

                    const unitInput = document.createElement("input");

                    unitInput.type = "text";

                    unitInput.className = "audit-edit-input";

                    unitInput.value = parameter.unit || "";

                    unitInput.dataset.componentIndex = componentIndex;

                    unitInput.dataset.parameterIndex = parameterIndex;

                    unitInput.dataset.field = "unit";

                    unitCell.appendChild(unitInput);

                    row.appendChild(unitCell);

                    createCell(
                        row,
                        parameter.confidence === null ||
                        parameter.confidence === undefined
                            ? "-"
                            : `${(Number(parameter.confidence) * 100).toFixed(1)}%`
                    );

                    createCell(
                        row,
                        getEvidence(parameter)
                    );

                    tbody.appendChild(row);

                });

                table.appendChild(tbody);

                wrapper.appendChild(table);

                card.appendChild(wrapper);

            }

            container.appendChild(card);

        });

    }

    // ------------------------------------
    // Build corrected components
    // ------------------------------------

    function buildCorrectedComponents() {

        const components = JSON.parse(
            JSON.stringify(originalComponents)
        );

        const inputs = document.querySelectorAll(
            "#editableComponents [data-field]"
        );

        inputs.forEach(input => {

            const componentIndex =
                Number(input.dataset.componentIndex);

            const parameterIndex =
                Number(input.dataset.parameterIndex);

            const field = input.dataset.field;

            const parameter =
                components[componentIndex]?.parameters?.[parameterIndex];

            if (!parameter) return;

            const value = input.value.trim();

            if (field === "name") {

                if (!value) {
                    throw new Error("Parameter names cannot be empty.");
                }

                parameter.name = value;

            }

            if (field === "unit") {

                parameter.unit = value || null;

            }

            if (field === "value") {

                if (!value) {
                    throw new Error("Parameter values cannot be empty.");
                }

                // Preserve the original numeric/text value type.
                if (
                    parameter.value_num !== null &&
                    parameter.value_num !== undefined
                ) {

                    const numericValue = Number(value);

                    if (!Number.isFinite(numericValue)) {

                        throw new Error(
                            `Parameter "${parameter.name}" must be numeric.`
                        );

                    }

                    parameter.value = numericValue;

                    parameter.value_num = numericValue;

                    parameter.value_text = null;

                } else {

                    parameter.value = value;

                    parameter.value_num = null;

                    parameter.value_text = value;

                }

            }

        });

        return components;

    }

    // ------------------------------------
    // Optional overwrite fields
    // ------------------------------------

    function getOverwriteOptions() {

        const checked =
            document.getElementById("confirmOverwrite").checked;

        if (!checked) {
            return {};
        }

        const raw =
            document.getElementById("expectedRevisions").value.trim();

        if (!raw) {

            throw new Error(
                "Expected component revisions are required for overwrite."
            );

        }

        let revisions;

        try {

            revisions = JSON.parse(raw);

        } catch {

            throw new Error(
                "Expected revisions must be valid JSON."
            );

        }

        if (
            !revisions ||
            Array.isArray(revisions) ||
            typeof revisions !== "object" ||
            Object.keys(revisions).length === 0
        ) {

            throw new Error(
                "Expected revisions must be a non-empty JSON object."
            );

        }

        return {
            confirm_overwrite: true,
            expected_revisions: revisions
        };

    }

    // ------------------------------------
    // Submit approval / rejection
    // ------------------------------------

    async function submitReview(action) {

        if (currentTaskId === null || !currentTask) {
            return;
        }

        const comment =
            document.getElementById("reviewComment").value.trim();

        if (action === "reject" && !comment) {

            showMessage(
                "detailMessage",
                "A review comment is required when rejecting a task.",
                "error"
            );

            return;

        }

        const confirmation =
            action === "approve"
                ? "Are you sure you want to approve this task and publish its data?"
                : "Are you sure you want to reject this task?";

        if (!confirm(confirmation)) {
            return;
        }

        let components;

        let overwriteOptions;

        try {

            components = buildCorrectedComponents();

            overwriteOptions = getOverwriteOptions();

        } catch (error) {

            showMessage(
                "detailMessage",
                error.message,
                "error"
            );

            return;

        }

        const payload = {
            action,
            comment,
            components,
            ...overwriteOptions
        };

        const approveButton =
            document.getElementById("approveButton");

        const rejectButton =
            document.getElementById("rejectButton");

        approveButton.disabled = true;

        rejectButton.disabled = true;

        showMessage(
            "detailMessage",
            action === "approve"
                ? "Submitting approval..."
                : "Submitting rejection..."
        );

        try {

            const response = await apiRequest(
                `/api/audit/tasks/${encodeURIComponent(currentTaskId)}`,
                {
                    method: "POST",
                    body: payload
                }
            );

            const data = getData(response);

            showMessage(
                "detailMessage",
                action === "approve"
                    ? `Task approved successfully. Published component IDs: ${(data.component_ids || []).join(", ") || "-"}.`
                    : "Task rejected successfully.",
                "success"
            );

            currentTask = null;

            originalComponents = [];

            // Close the completed review after a short delay.
            document.getElementById("reviewPanel").hidden = true;

            currentTaskId = null;

            await loadPendingReviews();

            await loadAuditLogs();

        } catch (error) {

            showMessage(
                "detailMessage",
                error.message,
                "error"
            );

            approveButton.disabled = false;

            rejectButton.disabled = false;

            handleAuthError(error);

        }

    }

    // ------------------------------------
    // Validation warnings
    // ------------------------------------

    function renderWarnings(warnings) {

        const container =
            document.getElementById("validationWarnings");

        container.innerHTML = "";

        if (!Array.isArray(warnings) || !warnings.length) {

            const message = document.createElement("p");

            message.className = "audit-no-warning";

            message.textContent = "No validation warnings.";

            container.appendChild(message);

            return;

        }

        warnings.forEach(warning => {

            const item = document.createElement("div");

            item.className = "audit-warning-item";

            item.textContent =
                typeof warning === "string"
                    ? warning
                    : JSON.stringify(warning);

            container.appendChild(item);

        });

    }

    // ------------------------------------
    // Load audit logs
    // ------------------------------------

    async function loadAuditLogs() {

        logsBody.innerHTML = `
            <tr>
                <td colspan="5">Loading audit history...</td>
            </tr>
        `;

        showMessage("logMessage", "");

        const params = new URLSearchParams({
            page: logPage,
            page_size: 20
        });

        const taskId =
            document.getElementById("logTaskId").value.trim();

        if (taskId) {
            params.set("task_id", taskId);
        }

        try {

            const response = await apiRequest(
                `/api/audit/logs?${params.toString()}`
            );

            const data = getData(response);

            const items = getItems(data);

            const total = Number(data.total ?? items.length);

            const pageSize = Number(data.page_size ?? 20);

            logPage = Number(data.page ?? logPage);

            logTotalPages = Math.max(
                1,
                Math.ceil(total / pageSize)
            );

            renderAuditLogs(items, total);

        } catch (error) {

            logsBody.innerHTML = `
                <tr>
                    <td colspan="5">Unable to load audit history.</td>
                </tr>
            `;

            showMessage(
                "logMessage",
                error.message,
                "error"
            );

            handleAuthError(error);

        }

    }

    // ------------------------------------
    // Render audit logs
    // ------------------------------------

    function renderAuditLogs(items, total) {

        logsBody.innerHTML = "";

        document.getElementById("logPageInfo").textContent =
            `Page ${logPage} / ${logTotalPages}`;

        document.getElementById("logPrevPage").disabled =
            logPage <= 1;

        document.getElementById("logNextPage").disabled =
            logPage >= logTotalPages;

        document.getElementById("approvedCount").textContent =
            items.filter(item =>
                String(item.action || item.review_status || "")
                    .toLowerCase() === "approve" ||
                String(item.action || item.review_status || "")
                    .toLowerCase() === "approved"
            ).length;

        document.getElementById("rejectedCount").textContent =
            items.filter(item =>
                String(item.action || item.review_status || "")
                    .toLowerCase() === "reject" ||
                String(item.action || item.review_status || "")
                    .toLowerCase() === "rejected"
            ).length;

        if (!items.length) {

            logsBody.innerHTML = `
                <tr>
                    <td colspan="5">No audit records found.</td>
                </tr>
            `;

            return;

        }

        items.forEach(log => {

            const row = document.createElement("tr");

            createCell(row, log.task_id);

            createCell(
                row,
                log.action ||
                log.review_status
            );

            createCell(
                row,
                log.reviewer ||
                log.reviewer_username ||
                log.username
            );

            createCell(
                row,
                formatDate(
                    log.reviewed_at ||
                    log.audit_time ||
                    log.created_time
                )
            );

            createCell(
                row,
                log.comment
            );

            logsBody.appendChild(row);

        });

    }

    // ------------------------------------
    // Authentication errors
    // ------------------------------------

    function handleAuthError(error) {

        const message = String(error.message || "");

        if (message.includes("401")) {

            clearAuth();

            window.location.href = "../login.html";

        }

        if (message.includes("403")) {

            showMessage(
                "listMessage",
                "Access denied. Please sign in with an admin or auditor account.",
                "error"
            );

        }

    }

    // ------------------------------------
    // Event listeners
    // ------------------------------------

    document.getElementById("refreshAudit")
        .addEventListener("click", async () => {

            await loadPendingReviews();

            await loadAuditLogs();

        });

    document.getElementById("closeReview")
        .addEventListener("click", () => {

            document.getElementById("reviewPanel").hidden = true;

            currentTaskId = null;

            currentTask = null;

        });

    document.getElementById("approveButton")
        .addEventListener("click", () => {

            submitReview("approve");

        });

    document.getElementById("rejectButton")
        .addEventListener("click", () => {

            submitReview("reject");

        });

    document.getElementById("prevPage")
        .addEventListener("click", () => {

            if (currentPage > 1) {

                currentPage--;

                loadPendingReviews();

            }

        });

    document.getElementById("nextPage")
        .addEventListener("click", () => {

            if (currentPage < totalPages) {

                currentPage++;

                loadPendingReviews();

            }

        });

    document.getElementById("refreshLogs")
        .addEventListener("click", () => {

            loadAuditLogs();

        });

    document.getElementById("filterLogs")
        .addEventListener("click", () => {

            logPage = 1;

            loadAuditLogs();

        });

    document.getElementById("resetLogs")
        .addEventListener("click", () => {

            document.getElementById("logTaskId").value = "";

            logPage = 1;

            loadAuditLogs();

        });

    document.getElementById("logPrevPage")
        .addEventListener("click", () => {

            if (logPage > 1) {

                logPage--;

                loadAuditLogs();

            }

        });

    document.getElementById("logNextPage")
        .addEventListener("click", () => {

            if (logPage < logTotalPages) {

                logPage++;

                loadAuditLogs();

            }

        });

    // ------------------------------------
    // Initialization
    // ------------------------------------

    loadPendingReviews();

    loadAuditLogs();

});
